<?php
/**
 * Plugin Name:       ChainPay Payment Gateway
 * Plugin URI:        https://chainpay.io
 * Description:       Accept Bitcoin, Litecoin and 12+ cryptocurrencies directly to your wallet. Non-custodial xPub HD wallet derivation, smart routing, underpayment recovery. Free: BTC + LTC. License unlocks all coins.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            ChainPay
 * Author URI:        https://chainpay.io
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       chainpay
 * Domain Path:       /languages
 * WC requires at least: 6.0
 * WC tested up to:   9.0
 */

defined( 'ABSPATH' ) || exit;

define( 'CHAINPAY_VERSION',    '1.0.0' );
define( 'CHAINPAY_FILE',       __FILE__ );
define( 'CHAINPAY_DIR',        plugin_dir_path( __FILE__ ) );
define( 'CHAINPAY_URL',        plugin_dir_url( __FILE__ ) );
define( 'CHAINPAY_API_BASE',   'https://api.chainpay.io/v1' );

// ── CRON INTERVALS ───────────────────────────────────────────────────────────
add_filter( 'cron_schedules', function( array $s ): array {
    $s['chainpay_1min']  = [ 'interval' => 60,  'display' => 'Every Minute' ];
    $s['chainpay_5min']  = [ 'interval' => 300, 'display' => 'Every 5 Minutes' ];
    return $s;
} );

// ── BOOT ON plugins_loaded ───────────────────────────────────────────────────
add_action( 'plugins_loaded', 'chainpay_boot', 10 );

function chainpay_boot(): void {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>ChainPay:</strong> WooCommerce must be installed and active.</p></div>';
        } );
        return;
    }

    // Load in dependency order
    require_once CHAINPAY_DIR . 'includes/class-chainpay-coin-registry.php';
    require_once CHAINPAY_DIR . 'includes/class-chainpay-license.php';
    require_once CHAINPAY_DIR . 'includes/class-chainpay-api.php';
    require_once CHAINPAY_DIR . 'includes/class-chainpay-price-feed.php';
    require_once CHAINPAY_DIR . 'includes/class-chainpay-xpub.php';
    require_once CHAINPAY_DIR . 'includes/class-chainpay-invoice.php';
    require_once CHAINPAY_DIR . 'includes/class-chainpay-webhook.php';
    require_once CHAINPAY_DIR . 'includes/class-chainpay-emails.php';
    require_once CHAINPAY_DIR . 'includes/class-chainpay-gateway.php';
    require_once CHAINPAY_DIR . 'admin/class-chainpay-admin.php';
    require_once CHAINPAY_DIR . 'admin/class-chainpay-order-meta.php';

    // Register WC gateway
    add_filter( 'woocommerce_payment_gateways', function( array $gateways ): array {
        $gateways[] = 'ChainPay_Gateway';
        return $gateways;
    } );

    // HPOS compatibility declaration
    add_action( 'before_woocommerce_init', function () {
        if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
                'custom_order_tables', CHAINPAY_FILE, true
            );
        }
    } );

    // Admin classes
    if ( is_admin() ) {
        new ChainPay_Admin();
        new ChainPay_Order_Meta();
    }

    // Always boot webhook + emails
    new ChainPay_Webhook();
    ChainPay_Emails::init();

    // Cron callbacks (registered here so classes exist)
    add_action( 'chainpay_cron_invoices', [ 'ChainPay_Invoice',    'cron_check' ] );
    add_action( 'chainpay_cron_prices',   [ 'ChainPay_Price_Feed', 'refresh_all' ] );
}

// ── ACTIVATION ───────────────────────────────────────────────────────────────
register_activation_hook( __FILE__, 'chainpay_activate' );

function chainpay_activate(): void {
    global $wpdb;
    $col = $wpdb->get_charset_collate();

    $sql1 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}chainpay_invoices (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        order_id      BIGINT UNSIGNED NOT NULL,
        invoice_id    VARCHAR(64)     NOT NULL,
        coin          VARCHAR(20)     NOT NULL,
        network       VARCHAR(80)     NOT NULL DEFAULT '',
        address       VARCHAR(255)    NOT NULL DEFAULT '',
        amount_crypto DECIMAL(28,10)  NOT NULL DEFAULT '0',
        amount_fiat   DECIMAL(12,2)   NOT NULL DEFAULT '0',
        fiat_currency VARCHAR(10)     NOT NULL DEFAULT 'USD',
        exchange_rate DECIMAL(24,8)   NOT NULL DEFAULT '0',
        status        VARCHAR(30)     NOT NULL DEFAULT 'pending',
        tx_hash       VARCHAR(255)             DEFAULT NULL,
        confirmations INT UNSIGNED             DEFAULT 0,
        expires_at    DATETIME        NOT NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY   invoice_id (invoice_id),
        KEY          order_id   (order_id),
        KEY          status     (status)
    ) $col;";

    $sql2 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}chainpay_addresses (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        coin       VARCHAR(20)     NOT NULL,
        address    VARCHAR(255)    NOT NULL,
        idx        INT UNSIGNED    NOT NULL DEFAULT 0,
        order_id   BIGINT UNSIGNED          DEFAULT NULL,
        used       TINYINT(1)      NOT NULL DEFAULT 0,
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY  address   (address),
        KEY         coin_used (coin, used)
    ) $col;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql1 );
    dbDelta( $sql2 );

    $defaults = [
        'chainpay_api_mode'           => 'live',
        'chainpay_invoice_timeout'    => 15,
        'chainpay_underpayment_pct'   => 1,
        'chainpay_confirmed_status'   => 'processing',
        'chainpay_pending_status'     => 'on-hold',
        'chainpay_expired_status'     => 'cancelled',
        'chainpay_smart_routing'      => 'yes',
        'chainpay_eth_fee_threshold'  => 30,
        'chainpay_underpayment_email' => 'yes',
        'chainpay_show_qr'            => 'yes',
        'chainpay_show_timer'         => 'yes',
        'chainpay_show_rate'          => 'yes',
        'chainpay_enabled_coins'      => [ 'BTC', 'LTC' ],
        'chainpay_db_version'         => '1.0',
    ];
    foreach ( $defaults as $key => $val ) {
        if ( false === get_option( $key ) ) {
            update_option( $key, $val );
        }
    }

    if ( ! wp_next_scheduled( 'chainpay_cron_invoices' ) ) {
        wp_schedule_event( time(), 'chainpay_1min', 'chainpay_cron_invoices' );
    }
    if ( ! wp_next_scheduled( 'chainpay_cron_prices' ) ) {
        wp_schedule_event( time(), 'chainpay_5min', 'chainpay_cron_prices' );
    }
}

// ── DEACTIVATION ─────────────────────────────────────────────────────────────
register_deactivation_hook( __FILE__, 'chainpay_deactivate' );

function chainpay_deactivate(): void {
    wp_clear_scheduled_hook( 'chainpay_cron_invoices' );
    wp_clear_scheduled_hook( 'chainpay_cron_prices' );
}
