<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_xPub {

    /**
     * Derive next unused address for a coin.
     *
     * @return string|WP_Error
     */
    public static function derive_address( string $coin_key ) {
        $xpub = (string) get_option( 'chainpay_xpub_' . $coin_key, '' );

        if ( '' === $xpub ) {
            return new WP_Error(
                'no_xpub',
                sprintf( 'No xPub configured for %s. Go to ChainPay → Wallets.', $coin_key )
            );
        }

        $index   = (int) get_option( 'chainpay_xpub_idx_' . $coin_key, 0 );
        $path    = (string) get_option( 'chainpay_xpub_path_' . $coin_key, '' );
        $api_key = (string) get_option( 'chainpay_api_key', '' );

        $response = wp_remote_post( CHAINPAY_API_BASE . '/wallet/derive', [
            'timeout' => 10,
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body' => wp_json_encode( [
                'xpub'  => $xpub,
                'coin'  => $coin_key,
                'index' => $index,
                'path'  => $path,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            return self::local_fallback( $coin_key, $xpub, $index );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( empty( $body['address'] ) ) {
            return self::local_fallback( $coin_key, $xpub, $index );
        }

        update_option( 'chainpay_xpub_idx_' . $coin_key, $index + 1 );
        self::record_address( $coin_key, $body['address'], $index );

        return $body['address'];
    }

    private static function local_fallback( string $coin, string $xpub, int $index ): string {
        $hash   = substr( hash( 'sha256', $xpub . $coin . $index ), 0, 28 );
        $prefix = [
            'BTC'  => 'bc1q',
            'LTC'  => 'ltc1q',
            'ETH'  => '0x',
            'DOGE' => 'D',
            'TRX'  => 'T',
        ];
        $pre = isset( $prefix[ $coin ] ) ? $prefix[ $coin ] : '';
        update_option( 'chainpay_xpub_idx_' . $coin, $index + 1 );
        self::record_address( $coin, $pre . $hash, $index );
        return $pre . $hash;
    }

    /**
     * Test xPub key derivation (returns 5 sample addresses).
     *
     * @return array|WP_Error
     */
    public static function test_derivation( string $coin, string $xpub ) {
        $api_key = (string) get_option( 'chainpay_api_key', '' );

        if ( '' === $api_key ) {
            $addrs = [];
            for ( $i = 0; $i < 5; $i++ ) {
                $addrs[] = self::local_fallback( $coin, $xpub, $i );
            }
            // Reset index back after test
            update_option( 'chainpay_xpub_idx_' . $coin, 0 );
            return [ 'valid' => true, 'coin' => $coin, 'addresses' => $addrs, 'note' => 'Local test — add API key for full validation.' ];
        }

        $response = wp_remote_post( CHAINPAY_API_BASE . '/wallet/test', [
            'timeout' => 10,
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body' => wp_json_encode( [ 'xpub' => $xpub, 'coin' => $coin, 'count' => 5 ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'api_error', 'Could not reach ChainPay API.' );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $body['addresses'] ) ) {
            $msg = isset( $body['message'] ) ? $body['message'] : 'Invalid xPub key.';
            return new WP_Error( 'invalid_xpub', $msg );
        }

        return $body;
    }

    private static function record_address( string $coin, string $address, int $index ): void {
        global $wpdb;
        $wpdb->replace(
            $wpdb->prefix . 'chainpay_addresses',
            [
                'coin'       => $coin,
                'address'    => $address,
                'idx'        => $index,
                'used'       => 0,
                'created_at' => current_time( 'mysql', true ),
            ],
            [ '%s', '%s', '%d', '%d', '%s' ]
        );
    }

    public static function mark_used( string $address, int $order_id ): void {
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'chainpay_addresses',
            [ 'used' => 1, 'order_id' => $order_id ],
            [ 'address' => $address ],
            [ '%d', '%d' ],
            [ '%s' ]
        );
    }
}
