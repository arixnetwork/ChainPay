<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_License {

    const OPT_KEY     = 'chainpay_license_key';
    const OPT_STATUS  = 'chainpay_license_status';
    const OPT_EXPIRES = 'chainpay_license_expires';
    const OPT_PLAN    = 'chainpay_license_plan';
    const OPT_CHECKED = 'chainpay_license_last_check';

    public static function is_active(): bool {
        $key = (string) get_option( self::OPT_KEY, '' );
        if ( '' === $key ) {
            return false;
        }
        $last = (int) get_option( self::OPT_CHECKED, 0 );
        if ( ( time() - $last ) > DAY_IN_SECONDS ) {
            self::verify( $key );
        }
        return 'active' === get_option( self::OPT_STATUS, 'inactive' );
    }

    public static function plan(): string {
        return (string) get_option( self::OPT_PLAN, 'free' );
    }

    /** @return array{success:bool,message:string} */
    public static function verify( string $key ): array {
        if ( '' === $key ) {
            self::set_inactive();
            return [ 'success' => false, 'message' => 'No license key provided.' ];
        }

        $api_mode = (string) get_option( 'chainpay_api_mode', 'live' );
        $base_url = ( 'test' === $api_mode ) ? 'https://sandbox.chainpay.io/v1' : CHAINPAY_API_BASE;

        $response = wp_remote_post(
            $base_url . '/license/verify',
            [
                'timeout' => 15,
                'headers' => [ 'Content-Type' => 'application/json' ],
                'body'    => wp_json_encode( [
                    'license_key' => $key,
                    'domain'      => home_url(),
                    'plugin_ver'  => CHAINPAY_VERSION,
                ] ),
            ]
        );

        update_option( self::OPT_CHECKED, time() );

        if ( is_wp_error( $response ) ) {
            return [ 'success' => false, 'message' => 'Could not reach ChainPay API.' ];
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! empty( $body['active'] ) ) {
            update_option( self::OPT_KEY,     $key );
            update_option( self::OPT_STATUS,  'active' );
            update_option( self::OPT_EXPIRES, isset( $body['expires'] ) ? $body['expires'] : '' );
            update_option( self::OPT_PLAN,    isset( $body['plan'] ) ? $body['plan'] : 'pro' );
            return [
                'success' => true,
                'message' => 'License activated.',
                'plan'    => isset( $body['plan'] ) ? $body['plan'] : 'pro',
            ];
        }

        self::set_inactive();
        return [
            'success' => false,
            'message' => isset( $body['message'] ) ? $body['message'] : 'Invalid license key.',
        ];
    }

    public static function deactivate(): void {
        $key = (string) get_option( self::OPT_KEY, '' );
        if ( '' !== $key ) {
            wp_remote_post( CHAINPAY_API_BASE . '/license/deactivate', [
                'timeout' => 10,
                'headers' => [ 'Content-Type' => 'application/json' ],
                'body'    => wp_json_encode( [ 'license_key' => $key, 'domain' => home_url() ] ),
            ] );
        }
        self::set_inactive();
        delete_option( self::OPT_KEY );
    }

    private static function set_inactive(): void {
        update_option( self::OPT_STATUS, 'inactive' );
        update_option( self::OPT_PLAN,   'free' );
    }

    /** @return array{key:string,status:string,plan:string,expires:string} */
    public static function summary(): array {
        $key = (string) get_option( self::OPT_KEY, '' );
        return [
            'key'     => self::mask( $key ),
            'status'  => (string) get_option( self::OPT_STATUS, 'inactive' ),
            'plan'    => (string) get_option( self::OPT_PLAN, 'free' ),
            'expires' => (string) get_option( self::OPT_EXPIRES, '' ),
        ];
    }

    private static function mask( string $key ): string {
        if ( strlen( $key ) < 8 ) {
            return $key;
        }
        return substr( $key, 0, 8 ) . str_repeat( '*', max( 0, strlen( $key ) - 12 ) ) . substr( $key, -4 );
    }
}
