<?php
defined( 'ABSPATH' ) || exit;

// ─────────────────────────────────────────────────────────────────
// Payment Detected (Unconfirmed)
// ─────────────────────────────────────────────────────────────────
class ChainPay_Email_Detected extends WC_Email {

    /** @var array */
    public $invoice = [];

    public function __construct() {
        $this->id             = 'chainpay_detected';
        $this->title          = 'ChainPay — Payment Detected';
        $this->description    = 'Sent when a payment is seen on-chain but not yet confirmed.';
        $this->heading        = 'Payment received — awaiting confirmation';
        $this->subject        = '[{site_name}] We received your payment — Order #{order_number}';
        $this->customer_email = true;
        $this->placeholders   = [
            '{site_name}'    => $this->get_from_name(),
            '{order_number}' => '',
        ];
        parent::__construct();
    }

    public function trigger( $order_id, $order = false, array $invoice = [] ): void {
        $this->setup_locale();
        if ( $order_id && ! ( $order instanceof WC_Order ) ) {
            $order = wc_get_order( $order_id );
        }
        if ( ! $order ) {
            $this->restore_locale();
            return;
        }
        $this->object                         = $order;
        $this->invoice                        = $invoice;
        $this->recipient                      = $order->get_billing_email();
        $this->placeholders['{order_number}'] = $order->get_order_number();
        if ( $this->is_enabled() && $this->get_recipient() ) {
            $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
        }
        $this->restore_locale();
    }

    public function get_content_html(): string {
        $order   = $this->object;
        $invoice = $this->invoice;
        $coin    = ChainPay_Coin_Registry::get( isset( $invoice['coin'] ) ? $invoice['coin'] : 'BTC' );
        $confs_r = $coin ? $coin['confirms'] : 1;
        $confs_c = isset( $invoice['confirmations'] ) ? $invoice['confirmations'] : 0;

        ob_start();
        ?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">
<style>
body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f5f5;margin:0;padding:20px;}
.w{max-width:580px;margin:0 auto;}
.hd{background:#1a1a2e;border-radius:12px 12px 0 0;padding:24px 32px;text-align:center;}
.hd-logo{font-size:20px;font-weight:800;color:#fff;}.hd-logo span{color:#3b82f6;}
.bd{background:#fff;padding:32px;border-radius:0 0 12px 12px;border:1px solid #e8e8e8;border-top:none;}
.ic{text-align:center;font-size:48px;margin-bottom:14px;}
.h1{font-size:22px;font-weight:800;color:#1a1a1a;text-align:center;margin-bottom:8px;}
.sub{font-size:14px;color:#666;text-align:center;margin-bottom:20px;line-height:1.6;}
.alert{background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:12px 16px;font-size:13px;color:#78350f;margin-bottom:16px;}
.box{background:#f8f8f8;border-radius:10px;padding:16px;margin-bottom:16px;}
.ft{text-align:center;font-size:11px;color:#aaa;margin-top:18px;}
</style></head>
<body><div class="w">
<div class="hd"><div class="hd-logo">Chain<span>Pay</span></div></div>
<div class="bd">
  <div class="ic">&#9203;</div>
  <div class="h1">Payment Received!</div>
  <div class="sub">Hi <?php echo esc_html( $order->get_billing_first_name() ); ?>, we detected your payment for order <strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong>. It is awaiting blockchain confirmation.</div>
  <div class="alert"><strong>Please wait.</strong> Your payment is being confirmed by the network. We will email you once confirmed.</div>
  <div class="box"><?php echo ChainPay_Emails::payment_details_html( $order, $invoice ); ?></div>
  <p style="font-size:12px;color:#999;text-align:center;">Required confirmations: <?php echo esc_html( (string) $confs_r ); ?> &middot; Current: <?php echo esc_html( (string) $confs_c ); ?></p>
</div>
<div class="ft"><?php echo esc_html( get_bloginfo( 'name' ) ); ?> &middot; Powered by ChainPay</div>
</div></body></html>
        <?php
        return ob_get_clean();
    }

    public function get_content_plain(): string {
        $order   = $this->object;
        $invoice = $this->invoice;
        $coin    = isset( $invoice['coin'] ) ? $invoice['coin'] : '';
        $crypto  = isset( $invoice['amount_crypto'] ) ? $invoice['amount_crypto'] : '';
        $network = isset( $invoice['network'] ) ? $invoice['network'] : '';
        $tx      = isset( $invoice['tx_hash'] ) ? $invoice['tx_hash'] : 'pending';
        $confs   = isset( $invoice['confirmations'] ) ? $invoice['confirmations'] : 0;
        return sprintf(
            "PAYMENT DETECTED\n\nHi %s,\n\nWe detected your payment for order #%s on the %s network. Awaiting confirmation.\n\nAmount: %s %s\nTX: %s\nConfirmations: %s\n\n%s",
            $order->get_billing_first_name(), $order->get_order_number(), $network,
            $crypto, $coin, $tx, $confs, get_bloginfo( 'name' )
        );
    }
}

// ─────────────────────────────────────────────────────────────────
// Underpayment Notice
// ─────────────────────────────────────────────────────────────────
class ChainPay_Email_Underpayment extends WC_Email {

    /** @var array */
    public $invoice = [];
    /** @var string */
    public $received = '';

    public function __construct() {
        $this->id             = 'chainpay_underpayment';
        $this->title          = 'ChainPay — Underpayment Notice';
        $this->description    = 'Sent when a customer pays less than the required amount.';
        $this->heading        = 'Action required: Underpayment detected';
        $this->subject        = '[{site_name}] Please complete your payment — Order #{order_number}';
        $this->customer_email = true;
        $this->placeholders   = [
            '{site_name}'    => $this->get_from_name(),
            '{order_number}' => '',
        ];
        parent::__construct();
    }

    public function trigger( $order_id, $order = false, array $invoice = [], string $received = '' ): void {
        $this->setup_locale();
        if ( $order_id && ! ( $order instanceof WC_Order ) ) {
            $order = wc_get_order( $order_id );
        }
        if ( ! $order ) {
            $this->restore_locale();
            return;
        }
        $this->object                         = $order;
        $this->invoice                        = $invoice;
        $this->received                       = $received;
        $this->recipient                      = $order->get_billing_email();
        $this->placeholders['{order_number}'] = $order->get_order_number();
        if ( $this->is_enabled() && $this->get_recipient() ) {
            $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
        }
        $this->send( (string) get_option( 'admin_email' ), '[ADMIN] Underpayment — Order #' . $order->get_order_number(), $this->get_content(), $this->get_headers(), [] );
        $this->restore_locale();
    }

    public function get_content_html(): string {
        $order    = $this->object;
        $invoice  = $this->invoice;
        $received = $this->received;
        $coin     = ChainPay_Coin_Registry::get( isset( $invoice['coin'] ) ? $invoice['coin'] : 'BTC' );
        $symbol   = $coin ? $coin['symbol'] : ( isset( $invoice['coin'] ) ? $invoice['coin'] : '' );
        $expected = isset( $invoice['amount_crypto'] ) ? $invoice['amount_crypto'] : '';
        $address  = isset( $invoice['address'] ) ? $invoice['address'] : '';
        $short    = number_format( (float) $expected - (float) $received, 8, '.', '' );

        ob_start();
        ?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">
<style>
body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f5f5;margin:0;padding:20px;}
.w{max-width:580px;margin:0 auto;}
.hd{background:#1a1a2e;border-radius:12px 12px 0 0;padding:24px 32px;text-align:center;}
.hd-logo{font-size:20px;font-weight:800;color:#fff;}.hd-logo span{color:#ef4444;}
.bd{background:#fff;padding:32px;border-radius:0 0 12px 12px;border:1px solid #e8e8e8;border-top:none;}
.ic{text-align:center;font-size:48px;margin-bottom:14px;}
.h1{font-size:22px;font-weight:800;color:#1a1a1a;text-align:center;margin-bottom:8px;}
.sub{font-size:14px;color:#666;text-align:center;margin-bottom:20px;line-height:1.6;}
.short{background:#fff5f5;border:1px solid #fecaca;border-radius:10px;padding:18px;text-align:center;margin-bottom:16px;}
.short-lbl{font-size:11px;color:#991b1b;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px;}
.short-amt{font-size:26px;font-weight:800;color:#dc2626;font-family:monospace;}
.cmp{display:flex;gap:14px;margin-bottom:16px;}
.cmp-item{flex:1;background:#f8f8f8;border-radius:8px;padding:10px;text-align:center;}
.cmp-lbl{font-size:11px;color:#999;margin-bottom:4px;}
.cmp-val{font-size:13px;font-weight:700;font-family:monospace;}
.addr{background:#f8f8f8;border:1px solid #e8e8e8;border-radius:8px;padding:10px 14px;font-family:monospace;font-size:12px;word-break:break-all;margin-bottom:16px;}
.ft{text-align:center;font-size:11px;color:#aaa;margin-top:18px;}
</style></head>
<body><div class="w">
<div class="hd"><div class="hd-logo">Chain<span>Pay</span></div></div>
<div class="bd">
  <div class="ic">&#9888;&#65039;</div>
  <div class="h1">Underpayment Detected</div>
  <div class="sub">Hi <?php echo esc_html( $order->get_billing_first_name() ); ?>, we received less than required for order <strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong>. Please send the remaining balance.</div>
  <div class="short">
    <div class="short-lbl">Still required</div>
    <div class="short-amt"><?php echo esc_html( $short ); ?> <?php echo esc_html( $symbol ); ?></div>
  </div>
  <div class="cmp">
    <div class="cmp-item"><div class="cmp-lbl">Required</div><div class="cmp-val"><?php echo esc_html( $expected . ' ' . $symbol ); ?></div></div>
    <div class="cmp-item"><div class="cmp-lbl">Received</div><div class="cmp-val" style="color:#dc2626;"><?php echo esc_html( $received . ' ' . $symbol ); ?></div></div>
  </div>
  <p style="font-size:12px;color:#666;margin-bottom:6px;">Send the remaining <?php echo esc_html( $short . ' ' . $symbol ); ?> to:</p>
  <div class="addr"><?php echo esc_html( $address ); ?></div>
</div>
<div class="ft"><?php echo esc_html( get_bloginfo( 'name' ) ); ?> &middot; Powered by ChainPay</div>
</div></body></html>
        <?php
        return ob_get_clean();
    }

    public function get_content_plain(): string {
        $o = $this->object;
        $i = $this->invoice;
        return sprintf(
            "UNDERPAYMENT DETECTED\n\nHi %s,\n\nOrder #%s is underpaid.\nExpected: %s %s\nReceived: %s %s\nSend remaining to: %s\n\n%s",
            $o->get_billing_first_name(), $o->get_order_number(),
            isset( $i['amount_crypto'] ) ? $i['amount_crypto'] : '', isset( $i['coin'] ) ? $i['coin'] : '',
            $this->received, isset( $i['coin'] ) ? $i['coin'] : '',
            isset( $i['address'] ) ? $i['address'] : '',
            get_bloginfo( 'name' )
        );
    }
}

// ─────────────────────────────────────────────────────────────────
// Invoice Expired
// ─────────────────────────────────────────────────────────────────
class ChainPay_Email_Expired extends WC_Email {

    /** @var array */
    public $invoice = [];

    public function __construct() {
        $this->id             = 'chainpay_expired';
        $this->title          = 'ChainPay — Invoice Expired';
        $this->description    = 'Sent when a payment invoice expires without payment.';
        $this->heading        = 'Your payment invoice has expired';
        $this->subject        = '[{site_name}] Invoice expired — Order #{order_number}';
        $this->customer_email = true;
        $this->enabled        = 'no';
        $this->placeholders   = [
            '{site_name}'    => $this->get_from_name(),
            '{order_number}' => '',
        ];
        parent::__construct();
    }

    public function trigger( $order_id, $order = false, array $invoice = [] ): void {
        $this->setup_locale();
        if ( $order_id && ! ( $order instanceof WC_Order ) ) {
            $order = wc_get_order( $order_id );
        }
        if ( ! $order ) {
            $this->restore_locale();
            return;
        }
        $this->object                         = $order;
        $this->invoice                        = $invoice;
        $this->recipient                      = $order->get_billing_email();
        $this->placeholders['{order_number}'] = $order->get_order_number();
        if ( $this->is_enabled() && $this->get_recipient() ) {
            $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
        }
        $this->restore_locale();
    }

    public function get_content_html(): string {
        $order = $this->object;
        ob_start();
        ?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">
<style>
body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#f5f5f5;margin:0;padding:20px;}
.w{max-width:580px;margin:0 auto;}
.hd{background:#1a1a2e;border-radius:12px 12px 0 0;padding:24px 32px;text-align:center;}
.hd-logo{font-size:20px;font-weight:800;color:#fff;}.hd-logo span{color:#9ca3af;}
.bd{background:#fff;padding:32px;border-radius:0 0 12px 12px;border:1px solid #e8e8e8;border-top:none;}
.ic{text-align:center;font-size:48px;margin-bottom:14px;}
.h1{font-size:22px;font-weight:800;color:#1a1a1a;text-align:center;margin-bottom:8px;}
.sub{font-size:14px;color:#666;text-align:center;margin-bottom:20px;line-height:1.6;}
.btn{display:block;background:#1a1a2e;color:#fff;text-decoration:none;padding:13px 28px;border-radius:9px;font-weight:700;font-size:14px;text-align:center;margin:20px 0;}
.ft{text-align:center;font-size:11px;color:#aaa;margin-top:18px;}
</style></head>
<body><div class="w">
<div class="hd"><div class="hd-logo">Chain<span>Pay</span></div></div>
<div class="bd">
  <div class="ic">&#9201;</div>
  <div class="h1">Invoice Expired</div>
  <div class="sub">Hi <?php echo esc_html( $order->get_billing_first_name() ); ?>, your payment invoice for order <strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong> has expired. No funds were captured.</div>
  <p style="font-size:14px;color:#666;text-align:center;line-height:1.6;">If you still wish to complete your purchase, please place a new order.</p>
  <a class="btn" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">Return to Shop &rarr;</a>
</div>
<div class="ft"><?php echo esc_html( get_bloginfo( 'name' ) ); ?> &middot; Powered by ChainPay</div>
</div></body></html>
        <?php
        return ob_get_clean();
    }

    public function get_content_plain(): string {
        $o = $this->object;
        return sprintf(
            "INVOICE EXPIRED\n\nHi %s,\n\nYour invoice for order #%s has expired. Place a new order: %s\n\n%s",
            $o->get_billing_first_name(),
            $o->get_order_number(),
            wc_get_page_permalink( 'shop' ),
            get_bloginfo( 'name' )
        );
    }
}
