<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Email_Confirmed extends WC_Email {

    /** @var array */
    public $invoice = [];

    public function __construct() {
        $this->id             = 'chainpay_confirmed';
        $this->title          = 'ChainPay — Payment Confirmed';
        $this->description    = 'Sent to the customer when their crypto payment is fully confirmed on-chain.';
        $this->heading        = 'Your payment has been confirmed!';
        $this->subject        = '[{site_name}] Payment confirmed — Order #{order_number}';
        $this->customer_email = true;
        $this->placeholders   = [
            '{site_name}'    => $this->get_from_name(),
            '{order_number}' => '',
            '{order_date}'   => '',
        ];
        parent::__construct();
    }

    public function trigger( $order_id, $order = false, array $invoice = [] ): void {
        $this->setup_locale();

        if ( $order_id && ! ( $order instanceof WC_Order ) ) {
            $order = wc_get_order( $order_id );
        }
        if ( ! $order ) {
            $this->restore_locale();
            return;
        }

        $this->object                         = $order;
        $this->invoice                        = $invoice;
        $this->recipient                      = $order->get_billing_email();
        $this->placeholders['{order_number}'] = $order->get_order_number();
        $this->placeholders['{order_date}']   = wc_format_datetime( $order->get_date_created() );

        if ( $this->is_enabled() && $this->get_recipient() ) {
            $this->send(
                $this->get_recipient(),
                $this->get_subject(),
                $this->get_content(),
                $this->get_headers(),
                $this->get_attachments()
            );
        }

        if ( 'yes' === get_option( 'chainpay_admin_email_on_confirmed', 'yes' ) ) {
            $this->send(
                (string) get_option( 'admin_email' ),
                '[ADMIN] ' . $this->get_subject(),
                $this->get_content(),
                $this->get_headers(),
                []
            );
        }

        $this->restore_locale();
    }

    public function get_content_html(): string {
        $order   = $this->object;
        $invoice = $this->invoice;
        $coin    = ChainPay_Coin_Registry::get( isset( $invoice['coin'] ) ? $invoice['coin'] : 'BTC' );
        $color   = $coin ? $coin['color'] : '#f7931a';

        ob_start();
        ?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">
<style>
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f5f5f5;margin:0;padding:20px;}
.w{max-width:580px;margin:0 auto;}
.hd{background:#1a1a2e;border-radius:12px 12px 0 0;padding:24px 32px;text-align:center;}
.hd-logo{font-size:20px;font-weight:800;color:#fff;}
.hd-logo span{color:<?php echo esc_attr( $color ); ?>;}
.bd{background:#fff;padding:32px;border-radius:0 0 12px 12px;border:1px solid #e8e8e8;border-top:none;}
.ic{text-align:center;font-size:48px;margin-bottom:14px;}
.h1{font-size:22px;font-weight:800;color:#1a1a1a;text-align:center;margin-bottom:8px;}
.sub{font-size:14px;color:#666;text-align:center;margin-bottom:24px;line-height:1.6;}
.box{background:#f8f8f8;border-radius:10px;padding:20px;margin-bottom:20px;}
.btn{display:block;background:<?php echo esc_attr( $color ); ?>;color:#fff;text-decoration:none;padding:13px 28px;border-radius:9px;font-weight:700;font-size:15px;text-align:center;margin:20px 0;}
.ft{text-align:center;font-size:11px;color:#aaa;margin-top:18px;}
</style></head>
<body><div class="w">
<div class="hd"><div class="hd-logo">Chain<span>Pay</span></div></div>
<div class="bd">
  <div class="ic">&#9989;</div>
  <div class="h1">Payment Confirmed!</div>
  <div class="sub">Hi <?php echo esc_html( $order->get_billing_first_name() ); ?>, your payment for order <strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong> has been confirmed on the blockchain.</div>
  <div class="box"><?php echo ChainPay_Emails::payment_details_html( $order, $invoice ); ?></div>
  <a class="btn" href="<?php echo esc_url( $order->get_view_order_url() ); ?>">View Order &rarr;</a>
  <p style="font-size:13px;color:#999;text-align:center;">Your order is now being processed.</p>
</div>
<div class="ft"><?php echo esc_html( get_bloginfo( 'name' ) ); ?> &middot; Powered by ChainPay v<?php echo esc_html( CHAINPAY_VERSION ); ?></div>
</div></body></html>
        <?php
        return ob_get_clean();
    }

    public function get_content_plain(): string {
        $order   = $this->object;
        $invoice = $this->invoice;
        $coin    = ChainPay_Coin_Registry::get( isset( $invoice['coin'] ) ? $invoice['coin'] : 'BTC' );
        $symbol  = $coin ? $coin['symbol'] : ( isset( $invoice['coin'] ) ? $invoice['coin'] : '' );
        $crypto  = isset( $invoice['amount_crypto'] ) ? $invoice['amount_crypto'] : '';
        $tx      = isset( $invoice['tx_hash'] ) ? $invoice['tx_hash'] : 'N/A';
        $confs   = isset( $invoice['confirmations'] ) ? $invoice['confirmations'] : 0;

        return sprintf(
            "PAYMENT CONFIRMED\n\nHi %s,\n\nOrder #%s is confirmed.\n\nAmount: %s %s\nTX: %s\nConfirmations: %s\n\nView order: %s\n\n%s",
            $order->get_billing_first_name(),
            $order->get_order_number(),
            $crypto,
            $symbol,
            $tx,
            $confs,
            $order->get_view_order_url(),
            get_bloginfo( 'name' )
        );
    }
}
