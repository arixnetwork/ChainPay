<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Coin_Registry {

    /** @return array<string,array> */
    public static function all(): array {
        return [
            'BTC' => [
                'name'        => 'Bitcoin',
                'symbol'      => 'BTC',
                'icon'        => '₿',
                'color'       => '#f7931a',
                'network'     => 'Bitcoin Mainnet',
                'uri_scheme'  => 'bitcoin',
                'decimals'    => 8,
                'confirms'    => 1,
                'derivation'  => "m/84'/0'/0'",
                'coingecko'   => 'bitcoin',
                'rec_fee'     => '1 sat/byte',
                'free'        => true,
            ],
            'LTC' => [
                'name'        => 'Litecoin',
                'symbol'      => 'LTC',
                'icon'        => 'Ł',
                'color'       => '#3b82f6',
                'network'     => 'Litecoin Mainnet',
                'uri_scheme'  => 'litecoin',
                'decimals'    => 8,
                'confirms'    => 3,
                'derivation'  => "m/84'/2'/0'",
                'coingecko'   => 'litecoin',
                'rec_fee'     => '10 sat/byte',
                'free'        => true,
            ],
            'ETH' => [
                'name'        => 'Ethereum',
                'symbol'      => 'ETH',
                'icon'        => 'Ξ',
                'color'       => '#627eea',
                'network'     => 'Ethereum',
                'uri_scheme'  => 'ethereum',
                'decimals'    => 18,
                'confirms'    => 12,
                'derivation'  => "m/44'/60'/0'",
                'coingecko'   => 'ethereum',
                'rec_fee'     => '~$2 gas',
                'free'        => false,
            ],
            'USDT_TRC20' => [
                'name'        => 'Tether (TRC-20)',
                'symbol'      => 'USDT',
                'icon'        => '₮',
                'color'       => '#26a17b',
                'network'     => 'Tron (TRC-20)',
                'uri_scheme'  => 'tron',
                'decimals'    => 6,
                'confirms'    => 20,
                'derivation'  => "m/44'/195'/0'",
                'coingecko'   => 'tether',
                'rec_fee'     => '~$0.80',
                'free'        => false,
            ],
            'USDT_ERC20' => [
                'name'        => 'Tether (ERC-20)',
                'symbol'      => 'USDT',
                'icon'        => '₮',
                'color'       => '#26a17b',
                'network'     => 'Ethereum (ERC-20)',
                'uri_scheme'  => 'ethereum',
                'decimals'    => 6,
                'confirms'    => 12,
                'derivation'  => "m/44'/60'/0'",
                'coingecko'   => 'tether',
                'rec_fee'     => '~$2 gas',
                'free'        => false,
            ],
            'USDC' => [
                'name'        => 'USD Coin',
                'symbol'      => 'USDC',
                'icon'        => '$',
                'color'       => '#2775ca',
                'network'     => 'Ethereum (ERC-20)',
                'uri_scheme'  => 'ethereum',
                'decimals'    => 6,
                'confirms'    => 12,
                'derivation'  => "m/44'/60'/0'",
                'coingecko'   => 'usd-coin',
                'rec_fee'     => '~$2 gas',
                'free'        => false,
            ],
            'XMR' => [
                'name'        => 'Monero',
                'symbol'      => 'XMR',
                'icon'        => 'ɱ',
                'color'       => '#ff6600',
                'network'     => 'Monero',
                'uri_scheme'  => 'monero',
                'decimals'    => 12,
                'confirms'    => 10,
                'derivation'  => 'subaddress',
                'coingecko'   => 'monero',
                'rec_fee'     => '~$0.01',
                'free'        => false,
            ],
            'BNB' => [
                'name'        => 'BNB',
                'symbol'      => 'BNB',
                'icon'        => 'B',
                'color'       => '#f0b90b',
                'network'     => 'BNB Smart Chain',
                'uri_scheme'  => 'binancecoin',
                'decimals'    => 18,
                'confirms'    => 15,
                'derivation'  => "m/44'/60'/0'",
                'coingecko'   => 'binancecoin',
                'rec_fee'     => '~$0.15',
                'free'        => false,
            ],
            'DOGE' => [
                'name'        => 'Dogecoin',
                'symbol'      => 'DOGE',
                'icon'        => 'Ð',
                'color'       => '#c9a91b',
                'network'     => 'Dogecoin',
                'uri_scheme'  => 'dogecoin',
                'decimals'    => 8,
                'confirms'    => 6,
                'derivation'  => "m/44'/3'/0'",
                'coingecko'   => 'dogecoin',
                'rec_fee'     => '~1 DOGE',
                'free'        => false,
            ],
            'SOL' => [
                'name'        => 'Solana',
                'symbol'      => 'SOL',
                'icon'        => '◎',
                'color'       => '#9945ff',
                'network'     => 'Solana',
                'uri_scheme'  => 'solana',
                'decimals'    => 9,
                'confirms'    => 32,
                'derivation'  => "m/44'/501'/0'",
                'coingecko'   => 'solana',
                'rec_fee'     => '~$0.001',
                'free'        => false,
            ],
            'MATIC' => [
                'name'        => 'Polygon',
                'symbol'      => 'MATIC',
                'icon'        => '⬡',
                'color'       => '#8247e5',
                'network'     => 'Polygon',
                'uri_scheme'  => 'polygon',
                'decimals'    => 18,
                'confirms'    => 30,
                'derivation'  => "m/44'/60'/0'",
                'coingecko'   => 'matic-network',
                'rec_fee'     => '~$0.01',
                'free'        => false,
            ],
            'TRX' => [
                'name'        => 'Tron',
                'symbol'      => 'TRX',
                'icon'        => 'T',
                'color'       => '#ef0027',
                'network'     => 'Tron',
                'uri_scheme'  => 'tron',
                'decimals'    => 6,
                'confirms'    => 20,
                'derivation'  => "m/44'/195'/0'",
                'coingecko'   => 'tron',
                'rec_fee'     => '~$0.10',
                'free'        => false,
            ],
            'AVAX' => [
                'name'        => 'Avalanche',
                'symbol'      => 'AVAX',
                'icon'        => '▲',
                'color'       => '#e84142',
                'network'     => 'Avalanche C-Chain',
                'uri_scheme'  => 'avalanche',
                'decimals'    => 18,
                'confirms'    => 20,
                'derivation'  => "m/44'/9005'/0'",
                'coingecko'   => 'avalanche-2',
                'rec_fee'     => '~$0.10',
                'free'        => false,
            ],
            'ARB' => [
                'name'        => 'Arbitrum',
                'symbol'      => 'ARB',
                'icon'        => '○',
                'color'       => '#28a0f0',
                'network'     => 'Arbitrum One',
                'uri_scheme'  => 'arbitrum',
                'decimals'    => 18,
                'confirms'    => 20,
                'derivation'  => "m/44'/60'/0'",
                'coingecko'   => 'arbitrum',
                'rec_fee'     => '~$0.05',
                'free'        => false,
            ],
        ];
    }

    /** @return array|null */
    public static function get( string $key ) {
        $all = self::all();
        return isset( $all[ $key ] ) ? $all[ $key ] : null;
    }

    /** @return array<string,array> */
    public static function free_coins(): array {
        $result = [];
        foreach ( self::all() as $k => $c ) {
            if ( $c['free'] ) {
                $result[ $k ] = $c;
            }
        }
        return $result;
    }

    /** @return array<string,array> */
    public static function enabled(): array {
        $all      = self::all();
        $has_lic  = ChainPay_License::is_active();
        $selected = (array) get_option( 'chainpay_enabled_coins', [ 'BTC', 'LTC' ] );
        $out      = [];
        foreach ( $selected as $key ) {
            if ( ! isset( $all[ $key ] ) ) {
                continue;
            }
            if ( ! $all[ $key ]['free'] && ! $has_lic ) {
                continue;
            }
            $out[ $key ] = $all[ $key ];
        }
        return $out;
    }
}
