<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Gateway extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'chainpay';
        $this->has_fields         = false;
        $this->method_title       = 'ChainPay Crypto Payments';
        $this->method_description = 'Accept BTC, LTC and 12+ cryptocurrencies directly to your wallet. Non-custodial, xPub HD wallet derivation.';
        $this->supports           = [ 'products' ];

        $this->init_form_fields();
        $this->init_settings();

        $this->title       = $this->get_option( 'title', 'Cryptocurrency' );
        $this->description = $this->get_option( 'description', 'Pay with Bitcoin, Litecoin and more — directly to our wallet.' );
        $this->enabled     = $this->get_option( 'enabled' );

        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'wp_ajax_chainpay_get_invoice',        [ $this, 'ajax_get_invoice' ] );
        add_action( 'wp_ajax_nopriv_chainpay_get_invoice', [ $this, 'ajax_get_invoice' ] );
        add_action( 'wp_ajax_chainpay_select_coin',        [ $this, 'ajax_select_coin' ] );
        add_action( 'wp_ajax_nopriv_chainpay_select_coin', [ $this, 'ajax_select_coin' ] );
        add_action( 'wp_ajax_chainpay_poll_status',        [ $this, 'ajax_poll_status' ] );
        add_action( 'wp_ajax_nopriv_chainpay_poll_status', [ $this, 'ajax_poll_status' ] );
    }

    // ── FORM FIELDS ────────────────────────────────────────────────────────
    public function init_form_fields(): void {
        $this->form_fields = [
            'enabled' => [
                'title'   => __( 'Enable/Disable', 'chainpay' ),
                'type'    => 'checkbox',
                'label'   => __( 'Enable ChainPay Crypto Payments', 'chainpay' ),
                'default' => 'yes',
            ],
            'title' => [
                'title'    => __( 'Title', 'chainpay' ),
                'type'     => 'text',
                'default'  => 'Cryptocurrency',
                'desc_tip' => true,
                'description' => __( 'Shown to customers at checkout.', 'chainpay' ),
            ],
            'description' => [
                'title'   => __( 'Description', 'chainpay' ),
                'type'    => 'textarea',
                'default' => 'Pay with Bitcoin, Litecoin and more — directly to our wallet.',
            ],
        ];
    }

    // ── PROCESS PAYMENT ────────────────────────────────────────────────────
    public function process_payment( $order_id ): array {
        $order = wc_get_order( $order_id );
        $order->update_status( 'pending', 'ChainPay: Awaiting cryptocurrency payment.' );
        $order->save();
        wc_reduce_stock_levels( $order_id );
        WC()->cart->empty_cart();

        return [
            'result'   => 'success',
            'redirect' => add_query_arg( [
                'chainpay'  => '1',
                'order_id'  => $order_id,
                'order_key' => $order->get_order_key(),
            ], home_url( '/' ) ),
        ];
    }

    // ── ASSETS ─────────────────────────────────────────────────────────────
    public function enqueue_assets(): void {
        if ( ! is_checkout() && empty( $_GET['chainpay'] ) ) {
            return;
        }

        wp_enqueue_style( 'chainpay-checkout', CHAINPAY_URL . 'public/css/checkout.css', [], CHAINPAY_VERSION );
        wp_enqueue_script( 'qrcodejs', 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js', [], '1.0.0', true );
        wp_enqueue_script( 'chainpay-checkout', CHAINPAY_URL . 'public/js/checkout.js', [ 'jquery', 'qrcodejs' ], CHAINPAY_VERSION, true );

        wp_localize_script( 'chainpay-checkout', 'chainpay_params', [
            'ajax_url'    => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'chainpay_nonce' ),
            'order_id'    => isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0,
            'order_key'   => isset( $_GET['order_key'] ) ? sanitize_text_field( $_GET['order_key'] ) : '',
            'coins'       => ChainPay_Price_Feed::get_routed_coins(),
            'all_coins'   => ChainPay_Coin_Registry::all(),
            'free_coins'  => array_keys( ChainPay_Coin_Registry::free_coins() ),
            'has_license' => ChainPay_License::is_active(),
            'settings'    => [
                'show_qr'    => get_option( 'chainpay_show_qr', 'yes' ),
                'show_timer' => get_option( 'chainpay_show_timer', 'yes' ),
                'show_rate'  => get_option( 'chainpay_show_rate', 'yes' ),
                'timeout'    => (int) get_option( 'chainpay_invoice_timeout', 15 ),
            ],
            'store_name'  => get_bloginfo( 'name' ),
            'license_url' => admin_url( 'admin.php?page=chainpay-license' ),
        ] );
    }

    // ── AJAX: GET INVOICE ──────────────────────────────────────────────────
    public function ajax_get_invoice(): void {
        check_ajax_referer( 'chainpay_nonce', 'nonce' );

        $order_id  = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
        $order_key = isset( $_POST['order_key'] ) ? sanitize_text_field( $_POST['order_key'] ) : '';
        $coin_key  = isset( $_POST['coin'] ) ? sanitize_text_field( $_POST['coin'] ) : 'BTC';

        $order = wc_get_order( $order_id );
        if ( ! $order || ! hash_equals( $order->get_order_key(), $order_key ) ) {
            wp_send_json_error( 'Invalid order.' );
            return;
        }

        $existing = ChainPay_Invoice::get_by_order( $order_id );
        if ( $existing && $existing['coin'] === $coin_key && 'pending' === $existing['status'] ) {
            $coin = ChainPay_Coin_Registry::get( $coin_key );
            wp_send_json_success( array_merge( $existing, [
                'uri'       => ChainPay_Invoice::build_uri( $coin, $existing['address'], $existing['amount_crypto'] ),
                'coin_data' => $coin,
            ] ) );
            return;
        }

        $result = ChainPay_Invoice::create( $order, $coin_key );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
            return;
        }

        wp_send_json_success( $result );
    }

    // ── AJAX: SELECT COIN ──────────────────────────────────────────────────
    public function ajax_select_coin(): void {
        check_ajax_referer( 'chainpay_nonce', 'nonce' );

        $order_id  = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
        $order_key = isset( $_POST['order_key'] ) ? sanitize_text_field( $_POST['order_key'] ) : '';
        $coin_key  = isset( $_POST['coin'] ) ? sanitize_text_field( $_POST['coin'] ) : 'BTC';

        $order = wc_get_order( $order_id );
        if ( ! $order || ! hash_equals( $order->get_order_key(), $order_key ) ) {
            wp_send_json_error( 'Invalid order.' );
            return;
        }

        $enabled = ChainPay_Price_Feed::get_routed_coins();
        if ( ! isset( $enabled[ $coin_key ] ) ) {
            wp_send_json_error( 'Coin not available.' );
            return;
        }

        $result = ChainPay_Invoice::create( $order, $coin_key );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
            return;
        }

        wp_send_json_success( $result );
    }

    // ── AJAX: POLL STATUS ──────────────────────────────────────────────────
    public function ajax_poll_status(): void {
        check_ajax_referer( 'chainpay_nonce', 'nonce' );

        $invoice_id = isset( $_POST['invoice_id'] ) ? sanitize_text_field( $_POST['invoice_id'] ) : '';
        $invoice    = ChainPay_Invoice::get( $invoice_id );

        if ( ! $invoice ) {
            wp_send_json_error( 'Invoice not found.' );
            return;
        }

        $order        = wc_get_order( $invoice['order_id'] );
        $redirect_url = $order ? $order->get_checkout_order_received_url() : '';

        wp_send_json_success( [
            'status'        => $invoice['status'],
            'confirmations' => isset( $invoice['confirmations'] ) ? $invoice['confirmations'] : 0,
            'tx_hash'       => isset( $invoice['tx_hash'] ) ? $invoice['tx_hash'] : '',
            'redirect_url'  => $redirect_url,
            'expires_at'    => $invoice['expires_at'],
        ] );
    }

    // ── PAYMENT PAGE ───────────────────────────────────────────────────────
    public static function maybe_show_payment_page(): void {
        if ( empty( $_GET['chainpay'] ) ) {
            return;
        }

        $order_id  = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
        $order_key = isset( $_GET['order_key'] ) ? sanitize_text_field( $_GET['order_key'] ) : '';

        $order = wc_get_order( $order_id );
        if ( ! $order || ! hash_equals( $order->get_order_key(), $order_key ) ) {
            wp_die( 'Invalid payment link.', 'ChainPay', [ 'response' => 404 ] );
        }

        if ( $order->is_paid() ) {
            wp_redirect( $order->get_checkout_order_received_url() );
            exit;
        }

        include CHAINPAY_DIR . 'templates/payment-page.php';
        exit;
    }
}

add_action( 'template_redirect', [ 'ChainPay_Gateway', 'maybe_show_payment_page' ] );
