<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Webhook {

    public function __construct() {
        add_filter( 'query_vars', [ $this, 'add_query_var' ] );
        add_action( 'init',              [ $this, 'add_rewrite_rule' ] );
        add_action( 'template_redirect', [ $this, 'handle' ] );
    }

    public function add_query_var( array $vars ): array {
        $vars[] = 'chainpay_ipn';
        return $vars;
    }

    public function add_rewrite_rule(): void {
        add_rewrite_rule( '^chainpay-ipn/?$', 'index.php?chainpay_ipn=1', 'top' );
    }

    public function handle(): void {
        if ( ! get_query_var( 'chainpay_ipn' ) && empty( $_GET['chainpay_ipn'] ) ) {
            return;
        }

        if ( 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
            status_header( 405 );
            exit( 'Method Not Allowed' );
        }

        $raw    = file_get_contents( 'php://input' );
        $sig    = isset( $_SERVER['HTTP_X_CHAINPAY_SIGNATURE'] ) ? $_SERVER['HTTP_X_CHAINPAY_SIGNATURE'] : '';
        $secret = (string) get_option( 'chainpay_webhook_secret', '' );

        if ( '' !== $secret && ! $this->verify_sig( $raw, $sig, $secret ) ) {
            status_header( 401 );
            exit( 'Unauthorized' );
        }

        $payload = json_decode( $raw, true );
        if ( ! is_array( $payload ) ) {
            status_header( 400 );
            exit( 'Bad Request' );
        }

        $event      = isset( $payload['event'] )      ? $payload['event']      : '';
        $invoice_id = isset( $payload['invoice_id'] ) ? $payload['invoice_id'] : '';
        $tx_hash    = isset( $payload['tx_hash'] )    ? $payload['tx_hash']    : '';
        $confs      = isset( $payload['confirmations'] ) ? (int) $payload['confirmations'] : 0;
        $received   = isset( $payload['received'] )   ? $payload['received']   : '';
        $expected   = isset( $payload['expected'] )   ? $payload['expected']   : '';

        if ( 'payment.detected' === $event || 'payment.confirmed' === $event ) {
            ChainPay_Invoice::mark_paid( $invoice_id, $tx_hash, $confs );
        } elseif ( 'payment.underpaid' === $event ) {
            ChainPay_Invoice::mark_underpaid( $invoice_id, $received, $expected );
        } elseif ( 'invoice.expired' === $event ) {
            $inv = ChainPay_Invoice::get( $invoice_id );
            if ( $inv && 'pending' === $inv['status'] ) {
                $order = wc_get_order( $inv['order_id'] );
                if ( $order ) {
                    $order->update_status(
                        (string) get_option( 'chainpay_expired_status', 'cancelled' ),
                        'ChainPay: Invoice expired (webhook).'
                    );
                }
            }
        }

        status_header( 200 );
        echo wp_json_encode( [ 'received' => true ] );
        exit;
    }

    private function verify_sig( string $payload, string $sig, string $secret ): bool {
        return hash_equals( hash_hmac( 'sha256', $payload, $secret ), $sig );
    }
}
