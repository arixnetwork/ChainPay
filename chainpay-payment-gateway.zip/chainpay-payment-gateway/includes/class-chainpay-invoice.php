<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Invoice {

    /**
     * Create a new invoice for an order.
     *
     * @param WC_Order $order
     * @param string   $coin_key
     * @return array|WP_Error
     */
    public static function create( $order, string $coin_key ) {
        global $wpdb;

        $coin = ChainPay_Coin_Registry::get( $coin_key );
        if ( ! $coin ) {
            return new WP_Error( 'invalid_coin', 'Invalid coin: ' . $coin_key );
        }

        $fiat     = (float) $order->get_total();
        $currency = $order->get_currency();
        $rate     = ChainPay_Price_Feed::get_rate( $coin_key );

        if ( $rate <= 0.0 ) {
            return new WP_Error( 'no_rate', 'Could not fetch exchange rate for ' . $coin_key );
        }

        $decimals      = isset( $coin['decimals'] ) ? (int) $coin['decimals'] : 8;
        $crypto_amount = ChainPay_Price_Feed::fiat_to_crypto( $fiat, $coin_key, $decimals );

        $address = ChainPay_xPub::derive_address( $coin_key );
        if ( is_wp_error( $address ) ) {
            $api_result = ChainPay_API::create_invoice( [
                'order_id' => $order->get_id(),
                'coin'     => $coin_key,
                'amount'   => $fiat,
                'currency' => $currency,
            ] );
            if ( is_wp_error( $api_result ) ) {
                return $api_result;
            }
            $address = $api_result['address'];
        }

        $invoice_id  = 'cp_' . uniqid( '', true );
        $timeout_min = (int) get_option( 'chainpay_invoice_timeout', 15 );
        $expires_at  = gmdate( 'Y-m-d H:i:s', time() + $timeout_min * 60 );
        $network     = isset( $coin['network'] ) ? $coin['network'] : '';

        $inserted = $wpdb->insert(
            $wpdb->prefix . 'chainpay_invoices',
            [
                'order_id'      => $order->get_id(),
                'invoice_id'    => $invoice_id,
                'coin'          => $coin_key,
                'network'       => $network,
                'address'       => $address,
                'amount_crypto' => $crypto_amount,
                'amount_fiat'   => $fiat,
                'fiat_currency' => $currency,
                'exchange_rate' => $rate,
                'status'        => 'pending',
                'expires_at'    => $expires_at,
                'created_at'    => current_time( 'mysql', true ),
            ],
            [ '%d', '%s', '%s', '%s', '%s', '%s', '%f', '%s', '%f', '%s', '%s', '%s' ]
        );

        if ( ! $inserted ) {
            return new WP_Error( 'db_error', 'Failed to save invoice to database.' );
        }

        $order->update_meta_data( '_chainpay_invoice_id',    $invoice_id );
        $order->update_meta_data( '_chainpay_coin',          $coin_key );
        $order->update_meta_data( '_chainpay_network',       $network );
        $order->update_meta_data( '_chainpay_address',       $address );
        $order->update_meta_data( '_chainpay_amount_crypto', $crypto_amount );
        $order->update_meta_data( '_chainpay_amount_fiat',   $fiat );
        $order->update_meta_data( '_chainpay_exchange_rate', $rate );
        $order->update_meta_data( '_chainpay_expires_at',    $expires_at );
        $order->update_meta_data( '_chainpay_status',        'pending' );
        $order->save();

        $order->add_order_note( sprintf(
            'ChainPay invoice created. Coin: %s | Amount: %s %s | Address: %s | Expires: %s',
            $coin['name'],
            $crypto_amount,
            $coin['symbol'],
            $address,
            $expires_at
        ) );

        return [
            'invoice_id'    => $invoice_id,
            'address'       => $address,
            'coin'          => $coin_key,
            'coin_data'     => $coin,
            'amount_crypto' => $crypto_amount,
            'amount_fiat'   => $fiat,
            'currency'      => $currency,
            'exchange_rate' => $rate,
            'expires_at'    => $expires_at,
            'uri'           => self::build_uri( $coin, $address, $crypto_amount ),
        ];
    }

    public static function build_uri( array $coin, string $address, string $amount ): string {
        $scheme = isset( $coin['uri_scheme'] ) ? $coin['uri_scheme'] : 'bitcoin';
        return sprintf(
            '%s:%s?amount=%s&label=%s',
            $scheme,
            $address,
            $amount,
            rawurlencode( get_bloginfo( 'name' ) )
        );
    }

    /**
     * @return array|null
     */
    public static function get_by_order( int $order_id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}chainpay_invoices WHERE order_id = %d ORDER BY created_at DESC LIMIT 1",
                $order_id
            ),
            ARRAY_A
        );
    }

    /**
     * @return array|null
     */
    public static function get( string $invoice_id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}chainpay_invoices WHERE invoice_id = %s",
                $invoice_id
            ),
            ARRAY_A
        );
    }

    public static function mark_paid( string $invoice_id, string $tx_hash, int $confirmations = 0 ): bool {
        global $wpdb;

        $invoice = self::get( $invoice_id );
        if ( ! $invoice ) {
            return false;
        }

        $required = (int) get_option( 'chainpay_confirmations_' . $invoice['coin'], 1 );
        $status   = $confirmations >= $required ? 'confirmed' : 'detected';

        $wpdb->update(
            $wpdb->prefix . 'chainpay_invoices',
            [ 'status' => $status, 'tx_hash' => $tx_hash, 'confirmations' => $confirmations ],
            [ 'invoice_id' => $invoice_id ],
            [ '%s', '%s', '%d' ],
            [ '%s' ]
        );

        $order = wc_get_order( $invoice['order_id'] );
        if ( ! $order ) {
            return false;
        }

        $order->update_meta_data( '_chainpay_tx_hash',       $tx_hash );
        $order->update_meta_data( '_chainpay_confirmations', $confirmations );
        $order->update_meta_data( '_chainpay_status',        $status );
        $order->save();

        if ( 'confirmed' === $status ) {
            $wc_status = (string) get_option( 'chainpay_confirmed_status', 'processing' );
            $order->update_status( $wc_status, sprintf(
                'ChainPay: Payment confirmed. TX: %s | Confirmations: %d | Coin: %s',
                $tx_hash, $confirmations, $invoice['coin']
            ) );
            ChainPay_Emails::send_payment_confirmed( $order, $invoice );
        } elseif ( 'detected' === $status ) {
            $wc_status = (string) get_option( 'chainpay_pending_status', 'on-hold' );
            $order->update_status( $wc_status, sprintf(
                'ChainPay: Payment detected (unconfirmed). TX: %s | Confirmations: %d/%d',
                $tx_hash, $confirmations, $required
            ) );
            ChainPay_Emails::send_payment_detected( $order, $invoice );
        }

        return true;
    }

    public static function mark_underpaid( string $invoice_id, string $received, string $expected ): void {
        global $wpdb;

        $invoice = self::get( $invoice_id );
        if ( ! $invoice ) {
            return;
        }

        $wpdb->update(
            $wpdb->prefix . 'chainpay_invoices',
            [ 'status' => 'underpaid' ],
            [ 'invoice_id' => $invoice_id ],
            [ '%s' ],
            [ '%s' ]
        );

        $order = wc_get_order( $invoice['order_id'] );
        if ( ! $order ) {
            return;
        }

        $order->update_meta_data( '_chainpay_status',          'underpaid' );
        $order->update_meta_data( '_chainpay_received_amount', $received );
        $order->save();

        $order->add_order_note( sprintf(
            'ChainPay: Underpayment. Received: %s | Expected: %s %s',
            $received, $expected, $invoice['coin']
        ) );

        if ( 'yes' === get_option( 'chainpay_underpayment_email', 'yes' ) ) {
            ChainPay_Emails::send_underpayment_notice( $order, $invoice, $received );
        }
    }

    public static function cron_check(): void {
        global $wpdb;

        // Expire overdue invoices
        $expired = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}chainpay_invoices
             WHERE status = 'pending' AND expires_at < UTC_TIMESTAMP()",
            ARRAY_A
        );

        foreach ( $expired as $inv ) {
            $wpdb->update(
                $wpdb->prefix . 'chainpay_invoices',
                [ 'status' => 'expired' ],
                [ 'id' => $inv['id'] ],
                [ '%s' ],
                [ '%d' ]
            );
            $order = wc_get_order( $inv['order_id'] );
            if ( $order ) {
                $wc_status = (string) get_option( 'chainpay_expired_status', 'cancelled' );
                $order->update_meta_data( '_chainpay_status', 'expired' );
                $order->save();
                $order->update_status( $wc_status, 'ChainPay: Invoice expired — no payment received.' );
                ChainPay_Emails::send_invoice_expired( $order, $inv );
            }
        }

        // Poll API for pending/detected invoices
        $pending = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}chainpay_invoices
             WHERE status IN ('pending','detected') AND expires_at > UTC_TIMESTAMP()",
            ARRAY_A
        );

        foreach ( $pending as $inv ) {
            $result = ChainPay_API::check_payment( $inv['address'], $inv['coin'], $inv['amount_crypto'] );
            if ( $result && ! empty( $result['tx_hash'] ) ) {
                $confs = isset( $result['confirmations'] ) ? (int) $result['confirmations'] : 0;
                self::mark_paid( $inv['invoice_id'], $result['tx_hash'], $confs );
            }
        }
    }

    public static function stats(): array {
        global $wpdb;
        $t = $wpdb->prefix . 'chainpay_invoices';
        return [
            'total'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ),
            'confirmed' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status='confirmed'" ),
            'pending'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status IN ('pending','detected')" ),
            'expired'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status='expired'" ),
            'revenue'   => (float) $wpdb->get_var( "SELECT COALESCE(SUM(amount_fiat),0) FROM {$t} WHERE status='confirmed'" ),
        ];
    }
}
