<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Price_Feed {

    const CACHE_KEY    = 'chainpay_prices';
    const CACHE_EXPIRY = 300;

    public static function get_rate( string $coin_key ): float {
        $prices = self::get_all();
        return isset( $prices[ $coin_key ] ) ? (float) $prices[ $coin_key ] : 0.0;
    }

    /** @return array<string,float> */
    public static function get_all(): array {
        $cached = get_transient( self::CACHE_KEY );
        if ( is_array( $cached ) && ! empty( $cached ) ) {
            return $cached;
        }
        return self::refresh_all();
    }

    /** @return array<string,float> */
    public static function refresh_all(): array {
        $coins    = ChainPay_Coin_Registry::all();
        $ids      = array_unique( array_column( $coins, 'coingecko' ) );
        $currency = strtolower( get_woocommerce_currency() );
        $id_str   = implode( ',', $ids );

        $url = add_query_arg(
            [ 'ids' => $id_str, 'vs_currencies' => $currency . ',usd' ],
            'https://api.coingecko.com/api/v3/simple/price'
        );

        $response = wp_remote_get( $url, [ 'timeout' => 10 ] );
        $prices   = [];

        if ( ! is_wp_error( $response ) ) {
            $data = json_decode( wp_remote_retrieve_body( $response ), true );
            if ( is_array( $data ) ) {
                foreach ( $coins as $key => $coin ) {
                    $cg_id = $coin['coingecko'];
                    if ( isset( $data[ $cg_id ][ $currency ] ) ) {
                        $prices[ $key ] = (float) $data[ $cg_id ][ $currency ];
                    } elseif ( isset( $data[ $cg_id ]['usd'] ) ) {
                        $prices[ $key ] = (float) $data[ $cg_id ]['usd'];
                    }
                }
            }
        }

        if ( empty( $prices ) ) {
            $prices = self::fallback_binance();
        }

        if ( ! empty( $prices ) ) {
            set_transient( self::CACHE_KEY, $prices, self::CACHE_EXPIRY );
        }

        return $prices;
    }

    /** @return array<string,float> */
    private static function fallback_binance(): array {
        $map = [
            'BTC'  => 'BTCUSDT',
            'ETH'  => 'ETHUSDT',
            'LTC'  => 'LTCUSDT',
            'BNB'  => 'BNBUSDT',
            'DOGE' => 'DOGEUSDT',
            'SOL'  => 'SOLUSDT',
            'MATIC'=> 'MATICUSDT',
            'TRX'  => 'TRXUSDT',
        ];

        $prices = [];
        foreach ( $map as $coin_key => $symbol ) {
            $r = wp_remote_get(
                'https://api.binance.com/api/v3/ticker/price?symbol=' . $symbol,
                [ 'timeout' => 5 ]
            );
            if ( ! is_wp_error( $r ) ) {
                $d = json_decode( wp_remote_retrieve_body( $r ), true );
                if ( isset( $d['price'] ) ) {
                    $prices[ $coin_key ] = (float) $d['price'];
                }
            }
        }

        // Stablecoins
        foreach ( [ 'USDT_TRC20', 'USDT_ERC20', 'USDC' ] as $k ) {
            $prices[ $k ] = 1.0;
        }

        return $prices;
    }

    public static function fiat_to_crypto( float $fiat, string $coin_key, int $decimals = 8 ): string {
        $rate = self::get_rate( $coin_key );
        if ( $rate <= 0.0 ) {
            return '0';
        }
        return number_format( $fiat / $rate, $decimals, '.', '' );
    }

    public static function get_eth_gas_usd(): float {
        $cached = get_transient( 'chainpay_eth_gas_usd' );
        if ( false !== $cached ) {
            return (float) $cached;
        }

        $r = wp_remote_get( 'https://api.ethgasstation.info/api/fee-estimate', [ 'timeout' => 5 ] );
        if ( ! is_wp_error( $r ) ) {
            $data    = json_decode( wp_remote_retrieve_body( $r ), true );
            $gwei    = isset( $data['gasPrice']['fast'] ) ? (float) $data['gasPrice']['fast'] : 30.0;
            $eth_usd = self::get_rate( 'ETH' );
            $gas_usd = ( $gwei * 21000 * 1e-9 ) * $eth_usd;
            set_transient( 'chainpay_eth_gas_usd', $gas_usd, 120 );
            return $gas_usd;
        }

        return 25.0;
    }

    /** @return array<string,array> */
    public static function get_routed_coins(): array {
        if ( 'yes' !== get_option( 'chainpay_smart_routing', 'yes' ) ) {
            return ChainPay_Coin_Registry::enabled();
        }

        $enabled   = ChainPay_Coin_Registry::enabled();
        $eth_gas   = self::get_eth_gas_usd();
        $threshold = (float) get_option( 'chainpay_eth_fee_threshold', 30 );
        $hide_eth  = $eth_gas > $threshold;

        $routed = [];
        foreach ( $enabled as $key => $coin ) {
            $net = isset( $coin['network'] ) ? $coin['network'] : '';
            if ( $hide_eth && ( false !== strpos( $net, 'Ethereum' ) || false !== strpos( $net, 'ERC' ) ) ) {
                continue;
            }
            $routed[ $key ] = $coin;
        }

        if ( empty( $routed ) && isset( $enabled['BTC'] ) ) {
            $routed['BTC'] = $enabled['BTC'];
        }

        return $routed;
    }
}
