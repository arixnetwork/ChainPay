<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_API {

    private static function base(): string {
        return 'test' === get_option( 'chainpay_api_mode', 'live' )
            ? 'https://sandbox.chainpay.io/v1'
            : CHAINPAY_API_BASE;
    }

    private static function headers(): array {
        return [
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . (string) get_option( 'chainpay_api_key', '' ),
            'X-Plugin-Ver'  => CHAINPAY_VERSION,
            'X-Store-URL'   => home_url(),
        ];
    }

    /**
     * Create an invoice via API.
     *
     * @param array $data
     * @return array|WP_Error
     */
    public static function create_invoice( array $data ) {
        $response = wp_remote_post( self::base() . '/invoices', [
            'timeout' => 12,
            'headers' => self::headers(),
            'body'    => wp_json_encode( $data ),
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( empty( $body['address'] ) ) {
            $msg = isset( $body['message'] ) ? $body['message'] : 'Invoice creation failed.';
            return new WP_Error( 'api_fail', $msg );
        }

        return $body;
    }

    /**
     * Check on-chain payment status.
     *
     * @return array|null
     */
    public static function check_payment( string $address, string $coin, string $expected ) {
        $url = add_query_arg(
            [ 'address' => $address, 'coin' => $coin, 'expected' => $expected ],
            self::base() . '/payment/check'
        );

        $response = wp_remote_get( $url, [
            'timeout' => 8,
            'headers' => self::headers(),
        ] );

        if ( is_wp_error( $response ) ) {
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return is_array( $body ) ? $body : null;
    }

    public static function ping(): bool {
        $response = wp_remote_get( self::base() . '/ping', [
            'timeout' => 6,
            'headers' => self::headers(),
        ] );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return ! empty( $body['ok'] );
    }
}
