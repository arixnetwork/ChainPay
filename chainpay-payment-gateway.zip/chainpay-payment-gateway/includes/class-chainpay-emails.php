<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Emails {

    public static function init(): void {
        add_filter( 'woocommerce_email_classes', [ __CLASS__, 'register' ] );
    }

    public static function register( array $emails ): array {
        require_once CHAINPAY_DIR . 'includes/emails/class-email-payment-confirmed.php';
        require_once CHAINPAY_DIR . 'includes/emails/class-email-others.php';

        $emails['ChainPay_Email_Confirmed']   = new ChainPay_Email_Confirmed();
        $emails['ChainPay_Email_Detected']    = new ChainPay_Email_Detected();
        $emails['ChainPay_Email_Underpayment']= new ChainPay_Email_Underpayment();
        $emails['ChainPay_Email_Expired']     = new ChainPay_Email_Expired();
        return $emails;
    }

    /** @param WC_Order $order */
    public static function send_payment_confirmed( $order, array $invoice ): void {
        if ( 'yes' !== get_option( 'chainpay_email_on_confirmed', 'yes' ) ) {
            return;
        }
        $mailer = WC()->mailer();
        if ( isset( $mailer->emails['ChainPay_Email_Confirmed'] ) ) {
            $mailer->emails['ChainPay_Email_Confirmed']->trigger( $order->get_id(), $order, $invoice );
        }
    }

    /** @param WC_Order $order */
    public static function send_payment_detected( $order, array $invoice ): void {
        if ( 'yes' !== get_option( 'chainpay_email_on_detected', 'yes' ) ) {
            return;
        }
        $mailer = WC()->mailer();
        if ( isset( $mailer->emails['ChainPay_Email_Detected'] ) ) {
            $mailer->emails['ChainPay_Email_Detected']->trigger( $order->get_id(), $order, $invoice );
        }
    }

    /** @param WC_Order $order */
    public static function send_underpayment_notice( $order, array $invoice, string $received ): void {
        if ( 'yes' !== get_option( 'chainpay_underpayment_email', 'yes' ) ) {
            return;
        }
        $mailer = WC()->mailer();
        if ( isset( $mailer->emails['ChainPay_Email_Underpayment'] ) ) {
            $mailer->emails['ChainPay_Email_Underpayment']->trigger( $order->get_id(), $order, $invoice, $received );
        }
    }

    /** @param WC_Order $order */
    public static function send_invoice_expired( $order, array $invoice ): void {
        if ( 'yes' !== get_option( 'chainpay_email_on_expired', 'no' ) ) {
            return;
        }
        $mailer = WC()->mailer();
        if ( isset( $mailer->emails['ChainPay_Email_Expired'] ) ) {
            $mailer->emails['ChainPay_Email_Expired']->trigger( $order->get_id(), $order, $invoice );
        }
    }

    /**
     * Build payment details HTML table for emails.
     *
     * @param WC_Order $order
     */
    public static function payment_details_html( $order, array $invoice ): string {
        $coin      = ChainPay_Coin_Registry::get( isset( $invoice['coin'] ) ? $invoice['coin'] : 'BTC' );
        $coin_name = $coin ? $coin['name'] : ( isset( $invoice['coin'] ) ? $invoice['coin'] : '' );
        $symbol    = $coin ? $coin['symbol'] : ( isset( $invoice['coin'] ) ? $invoice['coin'] : '' );
        $color     = $coin ? $coin['color'] : '#f7931a';
        $network   = isset( $invoice['network'] ) ? $invoice['network'] : '';
        $rate      = isset( $invoice['exchange_rate'] ) ? $invoice['exchange_rate'] : 0;
        $tx        = isset( $invoice['tx_hash'] ) && $invoice['tx_hash'] ? '<code>' . esc_html( $invoice['tx_hash'] ) . '</code>' : '&mdash;';
        $confs     = isset( $invoice['confirmations'] ) ? $invoice['confirmations'] : 0;
        $inv_id    = isset( $invoice['invoice_id'] ) ? $invoice['invoice_id'] : '';
        $fiat_cur  = isset( $invoice['fiat_currency'] ) ? $invoice['fiat_currency'] : get_woocommerce_currency();
        $fiat_amt  = isset( $invoice['amount_fiat'] ) ? $invoice['amount_fiat'] : 0;
        $crypto    = isset( $invoice['amount_crypto'] ) ? $invoice['amount_crypto'] : '';

        $rows = [
            'Order ID'       => '#' . $order->get_id(),
            'Amount (Fiat)'  => wc_price( $fiat_amt, [ 'currency' => $fiat_cur ] ),
            'Amount (Crypto)'=> esc_html( $crypto . ' ' . $symbol ),
            'Coin / Network' => esc_html( $coin_name . ' — ' . $network ),
            'Exchange Rate'  => '1 ' . esc_html( $symbol ) . ' = $' . number_format( (float) $rate, 2 ),
            'TX Hash'        => $tx,
            'Confirmations'  => esc_html( (string) $confs ),
            'Invoice ID'     => '<code>' . esc_html( $inv_id ) . '</code>',
        ];

        $html  = '<table cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;font-size:14px;">';
        $html .= '<tr><td colspan="2" style="padding:8px 0;"><strong style="color:' . esc_attr( $color ) . ';">Payment Details</strong></td></tr>';
        foreach ( $rows as $label => $value ) {
            $html .= '<tr>';
            $html .= '<td style="padding:6px 12px 6px 0;color:#666;width:140px;border-bottom:1px solid #f0f0f0;">' . esc_html( $label ) . '</td>';
            $html .= '<td style="padding:6px 0;font-weight:500;border-bottom:1px solid #f0f0f0;">' . $value . '</td>';
            $html .= '</tr>';
        }
        $html .= '</table>';
        return $html;
    }
}
