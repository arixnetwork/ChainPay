/* global jQuery, chainpay_admin */
(function ($) {
    'use strict';

    var nonce    = chainpay_admin.nonce;
    var ajax_url = chainpay_admin.ajax_url;
    var i18n     = chainpay_admin.i18n;

    /* ── SAVE SETTINGS ─────────────────────────────────────────────────── */
    window.cpSaveSettings = function () {
        var btn = document.getElementById('cp-save-btn');
        var msg = document.getElementById('cp-save-msg');
        if (!btn) return;

        btn.textContent = i18n.saving;
        btn.disabled    = true;

        // Collect all form fields
        var form     = document.getElementById('chainpay-settings-form');
        var settings = {};

        // Text / select inputs
        $(form).find('input[name], select[name]').each(function () {
            var n = $(this).attr('name');
            var t = $(this).attr('type');
            if (!n) return;
            if (t === 'checkbox') {
                // handled below
            } else if (n.endsWith('[]')) {
                // handled below
            } else {
                settings[n] = $(this).val();
            }
        });

        // Checkboxes — send 'yes'/'no'
        $(form).find('input[type="checkbox"]').each(function () {
            var n = $(this).attr('name');
            if (!n || n.endsWith('[]')) return;
            settings[n] = $(this).is(':checked') ? 'yes' : 'no';
        });

        // Checkbox arrays (enabled_coins)
        var coinsChecked = [];
        $(form).find('input[name="chainpay_enabled_coins[]"]:checked').each(function () {
            coinsChecked.push($(this).val());
        });
        if ($(form).find('input[name="chainpay_enabled_coins[]"]').length > 0) {
            settings['chainpay_enabled_coins'] = coinsChecked;
        }

        $.post(ajax_url, {
            action:   'chainpay_save_settings',
            nonce:    nonce,
            settings: settings
        }, function (r) {
            btn.textContent = 'Save Settings';
            btn.disabled    = false;
            if (msg) {
                msg.style.display = 'inline';
                if (r.success) {
                    msg.style.color = '#166534';
                    msg.textContent = i18n.saved;
                } else {
                    msg.style.color = '#dc2626';
                    msg.textContent = i18n.error;
                }
                setTimeout(function () { msg.style.display = 'none'; }, 3000);
            }
        }).fail(function () {
            btn.textContent = 'Save Settings';
            btn.disabled    = false;
        });
    };

    /* ── LICENSE ────────────────────────────────────────────────────────── */
    window.cpVerifyLicense = function () {
        var key = document.getElementById('cp_license_key_input');
        var res = document.getElementById('cp-license-result');
        if (!key || !res) return;

        var keyVal = key.value.trim();
        if (!keyVal) { showResult(res, 'Enter a license key.', 'red'); return; }

        showResult(res, 'Verifying…', 'orange');

        $.post(ajax_url, {
            action:      'chainpay_verify_license',
            nonce:       nonce,
            license_key: keyVal
        }, function (r) {
            if (r.success) {
                showResult(res, '✓ License activated! Reloading…', 'green');
                setTimeout(function () { window.location.reload(); }, 1500);
            } else {
                showResult(res, '✗ ' + (r.data || 'Invalid key.'), 'red');
            }
        });
    };

    window.cpRevokeLicense = function () {
        if (!confirm(i18n.confirm_revoke)) return;
        $.post(ajax_url, { action: 'chainpay_revoke_license', nonce: nonce }, function () {
            window.location.reload();
        });
    };

    /* ── XPUB ───────────────────────────────────────────────────────────── */
    window.cpSaveXpub = function (coin) {
        var xpubEl = document.getElementById('xpub_' + coin);
        if (!xpubEl) return;

        var form     = document.getElementById('chainpay-settings-form');
        var pathEl   = form ? form.querySelector('[name="chainpay_xpub_path_' + coin + '"]') : null;
        var gapEl    = form ? form.querySelector('[name="chainpay_xpub_gap_' + coin + '"]')  : null;

        $.post(ajax_url, {
            action: 'chainpay_save_xpub',
            nonce:  nonce,
            coin:   coin,
            xpub:   xpubEl.value.trim(),
            path:   pathEl ? pathEl.value : '',
            gap:    gapEl  ? gapEl.value  : 20
        }, function (r) {
            alert(r.success ? (r.data || 'Saved!') : 'Error: ' + (r.data || 'Unknown'));
            if (r.success) window.location.reload();
        });
    };

    window.cpTestXpub = function (coin) {
        var xpubEl  = document.getElementById('xpub_' + coin);
        var resultEl = document.getElementById('xpub-test-' + coin);
        if (!xpubEl || !resultEl) return;

        resultEl.style.display = 'block';
        resultEl.innerHTML     = '<span style="color:#888;">Deriving test addresses…</span>';

        $.post(ajax_url, {
            action: 'chainpay_test_xpub',
            nonce:  nonce,
            coin:   coin,
            xpub:   xpubEl.value.trim()
        }, function (r) {
            if (r.success && r.data && r.data.addresses) {
                var html = '<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px;"><strong style="color:#166534;">✓ Valid xPub — Sample addresses:</strong><ul style="margin:8px 0 0;padding-left:18px;">';
                r.data.addresses.forEach(function (a) {
                    html += '<li style="font-family:monospace;font-size:11px;color:#333;margin-bottom:3px;">' + a + '</li>';
                });
                html += '</ul></div>';
                resultEl.innerHTML = html;
            } else {
                resultEl.innerHTML = '<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px;color:#dc2626;">✗ ' + (r.data || 'Invalid xPub key.') + '</div>';
            }
        });
    };

    /* ── WEBHOOK TEST ───────────────────────────────────────────────────── */
    window.cpTestWebhook = function () {
        var res = document.getElementById('cp-webhook-result');
        if (res) { res.style.display = 'block'; res.innerHTML = '<span style="color:#888;">Sending…</span>'; }

        $.post(ajax_url, { action: 'chainpay_test_webhook', nonce: nonce }, function (r) {
            if (!res) return;
            if (r.success) {
                res.innerHTML = '<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:10px;color:#166534;">✓ ' + (r.data || 'Sent!') + '</div>';
            } else {
                res.innerHTML = '<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px;color:#dc2626;">✗ ' + (r.data || 'Failed.') + '</div>';
            }
        });
    };

    /* ── HELPER ─────────────────────────────────────────────────────────── */
    function showResult(el, msg, color) {
        var colors = { green: '#166534', red: '#dc2626', orange: '#92400e' };
        var bgs    = { green: '#f0fdf4', red: '#fef2f2', orange: '#fffbeb' };
        var bds    = { green: '#bbf7d0', red: '#fecaca', orange: '#fde68a' };
        el.style.display    = 'block';
        el.style.background = bgs[color] || '#fff';
        el.style.border     = '1px solid ' + (bds[color] || '#e0e0e0');
        el.style.borderRadius = '8px';
        el.style.padding    = '10px 14px';
        el.style.color      = colors[color] || '#333';
        el.style.fontSize   = '13px';
        el.textContent      = msg;
    }

}(jQuery));
