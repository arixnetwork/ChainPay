<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Admin {

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'add_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_notices',         [ $this, 'admin_notices' ] );
        add_action( 'wp_dashboard_setup',    [ $this, 'add_dashboard_widget' ] );

        add_action( 'wp_ajax_chainpay_save_settings',  [ $this, 'ajax_save_settings' ] );
        add_action( 'wp_ajax_chainpay_verify_license', [ $this, 'ajax_verify_license' ] );
        add_action( 'wp_ajax_chainpay_revoke_license', [ $this, 'ajax_revoke_license' ] );
        add_action( 'wp_ajax_chainpay_save_xpub',      [ $this, 'ajax_save_xpub' ] );
        add_action( 'wp_ajax_chainpay_test_xpub',      [ $this, 'ajax_test_xpub' ] );
        add_action( 'wp_ajax_chainpay_test_webhook',   [ $this, 'ajax_test_webhook' ] );
        add_action( 'wp_ajax_chainpay_resend_email',   [ $this, 'ajax_resend_email' ] );
    }

    // ── MENU ───────────────────────────────────────────────────────────────
    public function add_menu(): void {
        $icon = 'data:image/svg+xml;base64,' . base64_encode( '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13 3L4 14h7l-1 7 9-11h-7l1-7z" fill="#ff6b2b"/></svg>' );

        add_menu_page( 'ChainPay', 'ChainPay', 'manage_woocommerce', 'chainpay', [ $this, 'render_page' ], $icon, 56 );
        add_submenu_page( 'chainpay', 'General',       'General',       'manage_woocommerce', 'chainpay',          [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'Currencies',    'Currencies',    'manage_woocommerce', 'chainpay-coins',    [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'Wallets',       'Wallets',       'manage_woocommerce', 'chainpay-wallets',  [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'Payments',      'Payments',      'manage_woocommerce', 'chainpay-payments', [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'Checkout',      'Checkout',      'manage_woocommerce', 'chainpay-checkout', [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'Emails',        'Emails',        'manage_woocommerce', 'chainpay-emails',   [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'Webhooks',      'Webhooks',      'manage_woocommerce', 'chainpay-webhooks', [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'Smart Routing', 'Smart Routing', 'manage_woocommerce', 'chainpay-routing',  [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'License',       'License',       'manage_woocommerce', 'chainpay-license',  [ $this, 'render_page' ] );
        add_submenu_page( 'chainpay', 'Logs',          'Logs',          'manage_woocommerce', 'chainpay-logs',     [ $this, 'render_page' ] );
    }

    // ── ASSETS ─────────────────────────────────────────────────────────────
    public function enqueue_assets( string $hook ): void {
        if ( false === strpos( $hook, 'chainpay' ) ) {
            return;
        }
        wp_enqueue_style( 'chainpay-admin', CHAINPAY_URL . 'admin/css/admin.css', [], CHAINPAY_VERSION );
        wp_enqueue_script( 'chainpay-admin', CHAINPAY_URL . 'admin/js/admin.js', [ 'jquery' ], CHAINPAY_VERSION, true );
        wp_localize_script( 'chainpay-admin', 'chainpay_admin', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'chainpay_admin_nonce' ),
            'i18n'     => [
                'saved'          => __( 'Settings saved!', 'chainpay' ),
                'saving'         => __( 'Saving…', 'chainpay' ),
                'error'          => __( 'Error saving settings.', 'chainpay' ),
                'confirm_revoke' => __( 'Revoke license? This will disable all licensed coins.', 'chainpay' ),
            ],
        ] );
    }

    // ── ADMIN NOTICES ──────────────────────────────────────────────────────
    public function admin_notices(): void {
        if ( '' === get_option( 'chainpay_api_key', '' ) && current_user_can( 'manage_woocommerce' ) ) {
            $url = admin_url( 'admin.php?page=chainpay' );
            echo '<div class="notice notice-warning is-dismissible"><p><strong>ChainPay:</strong> Configure your xPub wallet key or API key to start accepting payments. <a href="' . esc_url( $url ) . '">Configure now &rarr;</a></p></div>';
        }
    }

    // ── DASHBOARD WIDGET ───────────────────────────────────────────────────
    public function add_dashboard_widget(): void {
        wp_add_dashboard_widget( 'chainpay_widget', 'ChainPay Overview', [ $this, 'render_dashboard_widget' ] );
    }

    public function render_dashboard_widget(): void {
        $stats = ChainPay_Invoice::stats();
        $lic   = ChainPay_License::summary();
        ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
            <div style="background:#fff7ed;border-radius:8px;padding:12px;border-left:3px solid #f7931a;">
                <div style="font-size:10px;color:#92400e;text-transform:uppercase;font-weight:600;margin-bottom:4px;">Revenue</div>
                <div style="font-size:20px;font-weight:800;"><?php echo wc_price( $stats['revenue'] ); ?></div>
            </div>
            <div style="background:#f0fdf4;border-radius:8px;padding:12px;border-left:3px solid #4caf50;">
                <div style="font-size:10px;color:#166534;text-transform:uppercase;font-weight:600;margin-bottom:4px;">Confirmed</div>
                <div style="font-size:20px;font-weight:800;"><?php echo esc_html( (string) $stats['confirmed'] ); ?></div>
            </div>
            <div style="background:#fffbeb;border-radius:8px;padding:12px;border-left:3px solid #f59e0b;">
                <div style="font-size:10px;color:#92400e;text-transform:uppercase;font-weight:600;margin-bottom:4px;">Pending</div>
                <div style="font-size:20px;font-weight:800;"><?php echo esc_html( (string) $stats['pending'] ); ?></div>
            </div>
            <div style="background:#fef2f2;border-radius:8px;padding:12px;border-left:3px solid #ef4444;">
                <div style="font-size:10px;color:#991b1b;text-transform:uppercase;font-weight:600;margin-bottom:4px;">Expired</div>
                <div style="font-size:20px;font-weight:800;"><?php echo esc_html( (string) $stats['expired'] ); ?></div>
            </div>
        </div>
        <div style="font-size:12px;color:#666;">
            License: <strong><?php echo esc_html( ucfirst( $lic['status'] ) ); ?></strong>
            <?php if ( 'active' === $lic['status'] ) : ?> &mdash; Plan: <strong><?php echo esc_html( ucfirst( $lic['plan'] ) ); ?></strong><?php endif; ?>
            &middot; <a href="<?php echo esc_url( admin_url( 'admin.php?page=chainpay' ) ); ?>">Settings</a>
        </div>
        <?php
    }

    // ── RENDER PAGE ────────────────────────────────────────────────────────
    public function render_page(): void {
        $page = isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : 'chainpay';
        $tab  = str_replace( 'chainpay-', '', $page );
        if ( 'chainpay' === $tab ) {
            $tab = 'general';
        }
        include CHAINPAY_DIR . 'admin/views/layout.php';
    }

    // ── AJAX: SAVE SETTINGS ────────────────────────────────────────────────
    public function ajax_save_settings(): void {
        check_ajax_referer( 'chainpay_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( 'Unauthorized' );
            return;
        }

        $data = isset( $_POST['settings'] ) ? $_POST['settings'] : [];

        $string_keys = [
            'chainpay_api_key', 'chainpay_api_mode', 'chainpay_store_name',
            'chainpay_confirmed_status', 'chainpay_pending_status', 'chainpay_expired_status',
            'chainpay_smart_routing', 'chainpay_show_qr', 'chainpay_show_timer',
            'chainpay_show_rate', 'chainpay_show_fee', 'chainpay_checkout_theme',
            'chainpay_email_on_confirmed', 'chainpay_email_on_detected',
            'chainpay_underpayment_email', 'chainpay_email_on_expired',
            'chainpay_admin_email_on_confirmed', 'chainpay_webhook_url', 'chainpay_webhook_secret',
        ];
        $int_keys = [ 'chainpay_invoice_timeout' ];
        $float_keys = [ 'chainpay_underpayment_pct', 'chainpay_eth_fee_threshold' ];

        foreach ( $string_keys as $key ) {
            if ( isset( $data[ $key ] ) ) {
                update_option( $key, sanitize_text_field( $data[ $key ] ) );
            }
        }
        foreach ( $int_keys as $key ) {
            if ( isset( $data[ $key ] ) ) {
                update_option( $key, absint( $data[ $key ] ) );
            }
        }
        foreach ( $float_keys as $key ) {
            if ( isset( $data[ $key ] ) ) {
                update_option( $key, (float) $data[ $key ] );
            }
        }
        if ( isset( $data['chainpay_enabled_coins'] ) ) {
            $coins = array_map( 'sanitize_text_field', (array) $data['chainpay_enabled_coins'] );
            update_option( 'chainpay_enabled_coins', $coins );
        }

        wp_send_json_success( 'Settings saved.' );
    }

    // ── AJAX: LICENSE ──────────────────────────────────────────────────────
    public function ajax_verify_license(): void {
        check_ajax_referer( 'chainpay_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( 'Unauthorized' );
            return;
        }
        $key    = isset( $_POST['license_key'] ) ? sanitize_text_field( $_POST['license_key'] ) : '';
        $result = ChainPay_License::verify( $key );
        if ( $result['success'] ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result['message'] );
        }
    }

    public function ajax_revoke_license(): void {
        check_ajax_referer( 'chainpay_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( 'Unauthorized' );
            return;
        }
        ChainPay_License::deactivate();
        wp_send_json_success( 'License revoked.' );
    }

    // ── AJAX: XPUB ─────────────────────────────────────────────────────────
    public function ajax_save_xpub(): void {
        check_ajax_referer( 'chainpay_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( 'Unauthorized' );
            return;
        }
        $coin = isset( $_POST['coin'] ) ? sanitize_text_field( $_POST['coin'] ) : '';
        $xpub = isset( $_POST['xpub'] ) ? sanitize_text_field( $_POST['xpub'] ) : '';
        $path = isset( $_POST['path'] ) ? sanitize_text_field( $_POST['path'] ) : '';
        $gap  = isset( $_POST['gap'] ) ? absint( $_POST['gap'] ) : 20;

        if ( '' === $xpub ) {
            wp_send_json_error( 'xPub key is required.' );
            return;
        }

        update_option( 'chainpay_xpub_' . $coin,      $xpub );
        update_option( 'chainpay_xpub_path_' . $coin, $path );
        update_option( 'chainpay_xpub_gap_' . $coin,  $gap );

        wp_send_json_success( 'xPub saved for ' . $coin . '.' );
    }

    public function ajax_test_xpub(): void {
        check_ajax_referer( 'chainpay_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( 'Unauthorized' );
            return;
        }
        $coin = isset( $_POST['coin'] ) ? sanitize_text_field( $_POST['coin'] ) : '';
        $xpub = isset( $_POST['xpub'] ) ? sanitize_text_field( $_POST['xpub'] ) : '';

        if ( '' === $xpub ) {
            wp_send_json_error( 'Enter an xPub key first.' );
            return;
        }

        $result = ChainPay_xPub::test_derivation( $coin, $xpub );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_message() );
            return;
        }
        wp_send_json_success( $result );
    }

    // ── AJAX: WEBHOOK TEST ─────────────────────────────────────────────────
    public function ajax_test_webhook(): void {
        check_ajax_referer( 'chainpay_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( 'Unauthorized' );
            return;
        }

        $url = (string) get_option( 'chainpay_webhook_url', '' );
        if ( '' === $url ) {
            wp_send_json_error( 'No webhook URL configured.' );
            return;
        }

        $payload = wp_json_encode( [ 'event' => 'test.ping', 'invoice_id' => 'test_' . uniqid(), 'timestamp' => time() ] );
        $secret  = (string) get_option( 'chainpay_webhook_secret', '' );
        $sig     = hash_hmac( 'sha256', $payload, $secret );

        $r = wp_remote_post( $url, [
            'timeout' => 10,
            'headers' => [ 'Content-Type' => 'application/json', 'X-ChainPay-Signature' => $sig ],
            'body'    => $payload,
        ] );

        if ( is_wp_error( $r ) ) {
            wp_send_json_error( 'Delivery failed: ' . $r->get_error_message() );
            return;
        }

        $code = wp_remote_retrieve_response_code( $r );
        wp_send_json_success( 'Webhook delivered. Response code: ' . $code );
    }

    // ── AJAX: RESEND EMAIL ─────────────────────────────────────────────────
    public function ajax_resend_email(): void {
        check_ajax_referer( 'chainpay_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( 'Unauthorized' );
            return;
        }

        $order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
        $type     = isset( $_POST['email_type'] ) ? sanitize_text_field( $_POST['email_type'] ) : 'confirmed';
        $order    = wc_get_order( $order_id );

        if ( ! $order ) {
            wp_send_json_error( 'Order not found.' );
            return;
        }

        $invoice = ChainPay_Invoice::get_by_order( $order_id );
        if ( ! $invoice ) {
            wp_send_json_error( 'No ChainPay invoice for this order.' );
            return;
        }

        if ( 'confirmed' === $type ) {
            ChainPay_Emails::send_payment_confirmed( $order, $invoice );
        } elseif ( 'detected' === $type ) {
            ChainPay_Emails::send_payment_detected( $order, $invoice );
        } elseif ( 'expired' === $type ) {
            ChainPay_Emails::send_invoice_expired( $order, $invoice );
        }

        wp_send_json_success( 'Email resent.' );
    }
}
