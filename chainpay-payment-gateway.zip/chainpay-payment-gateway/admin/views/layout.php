<?php
defined( 'ABSPATH' ) || exit;
/**
 * Admin layout — $tab is set by ChainPay_Admin::render_page() via include scope.
 * @var string $tab
 */
if ( ! isset( $tab ) ) { $tab = 'general'; }

$lic           = ChainPay_License::summary();
$has_license   = ChainPay_License::is_active();
$coins_all     = ChainPay_Coin_Registry::all();
$enabled_coins = (array) get_option( 'chainpay_enabled_coins', [ 'BTC', 'LTC' ] );
$tabs_nav = [
    'general'  => [ 'label' => 'General',       'page' => 'chainpay' ],
    'coins'    => [ 'label' => 'Currencies',     'page' => 'chainpay-coins' ],
    'wallets'  => [ 'label' => 'Wallets',        'page' => 'chainpay-wallets' ],
    'payments' => [ 'label' => 'Payments',       'page' => 'chainpay-payments' ],
    'checkout' => [ 'label' => 'Checkout',       'page' => 'chainpay-checkout' ],
    'emails'   => [ 'label' => 'Emails',         'page' => 'chainpay-emails' ],
    'webhooks' => [ 'label' => 'Webhooks',       'page' => 'chainpay-webhooks' ],
    'routing'  => [ 'label' => 'Smart Routing',  'page' => 'chainpay-routing' ],
    'license'  => [ 'label' => 'License',        'page' => 'chainpay-license' ],
    'logs'     => [ 'label' => 'Logs',           'page' => 'chainpay-logs' ],
];
?>
<div class="wrap chainpay-wrap">

<div class="cp-admin-header">
  <div class="cp-admin-logo">
    <div class="cp-admin-logo-mark">&#9889;</div>
    <div>
      <div class="cp-admin-logo-text">ChainPay</div>
      <div class="cp-admin-logo-sub">v<?php echo esc_html( CHAINPAY_VERSION ); ?> &middot; Crypto Payment Gateway</div>
    </div>
  </div>
  <div class="cp-admin-header-right">
    <?php if ( $has_license ) : ?>
      <span class="cp-lic-badge cp-lic-active">License Active &mdash; <?php echo esc_html( ucfirst( $lic['plan'] ) ); ?></span>
    <?php else : ?>
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=chainpay-license' ) ); ?>" class="cp-lic-badge cp-lic-free">Free Plan &middot; Upgrade &rarr;</a>
    <?php endif; ?>
  </div>
</div>

<div class="cp-tabs-bar">
  <?php foreach ( $tabs_nav as $t_key => $t_data ) : ?>
  <a href="<?php echo esc_url( admin_url( 'admin.php?page=' . $t_data['page'] ) ); ?>"
     class="cp-tab<?php echo ( $tab === $t_key ) ? ' active' : ''; ?>">
    <?php echo esc_html( $t_data['label'] ); ?>
  </a>
  <?php endforeach; ?>
</div>

<div class="cp-admin-content">
<form id="chainpay-settings-form">
<?php wp_nonce_field( 'chainpay_admin_nonce', 'chainpay_nonce' ); ?>

<?php if ( 'general' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">General Settings</div></div>
  <div class="cp-card">
    <div class="cp-card-head">API Configuration</div>
    <div class="cp-card-body">
      <div class="cp-field-row">
        <div class="cp-field-label">ChainPay API Key</div>
        <div class="cp-field-input">
          <input type="text" name="chainpay_api_key" value="<?php echo esc_attr( (string) get_option( 'chainpay_api_key', '' ) ); ?>" placeholder="cp_live_…" class="cp-input cp-input-mono" />
          <p class="cp-field-help">Get your key from <a href="https://app.chainpay.io" target="_blank">app.chainpay.io</a>. Required for price feeds &amp; address derivation.</p>
        </div>
      </div>
      <div class="cp-field-row">
        <div class="cp-field-label">API Mode</div>
        <div class="cp-field-input">
          <select name="chainpay_api_mode" class="cp-select">
            <option value="live" <?php selected( get_option( 'chainpay_api_mode', 'live' ), 'live' ); ?>>Live (Production)</option>
            <option value="test" <?php selected( get_option( 'chainpay_api_mode', 'live' ), 'test' ); ?>>Sandbox / Test</option>
          </select>
        </div>
      </div>
      <div class="cp-field-row">
        <div class="cp-field-label">Store Name</div>
        <div class="cp-field-input">
          <input type="text" name="chainpay_store_name" value="<?php echo esc_attr( (string) get_option( 'chainpay_store_name', get_bloginfo( 'name' ) ) ); ?>" class="cp-input" />
        </div>
      </div>
    </div>
  </div>
  <?php $stats = ChainPay_Invoice::stats(); ?>
  <div class="cp-card">
    <div class="cp-card-head">Statistics</div>
    <div class="cp-card-body">
      <div class="cp-stats-grid">
        <div class="cp-stat"><div class="cp-stat-val" style="color:#f7931a;"><?php echo wc_price( $stats['revenue'] ); ?></div><div class="cp-stat-label">Revenue</div></div>
        <div class="cp-stat"><div class="cp-stat-val" style="color:#4caf50;"><?php echo esc_html( (string) $stats['confirmed'] ); ?></div><div class="cp-stat-label">Confirmed</div></div>
        <div class="cp-stat"><div class="cp-stat-val" style="color:#f59e0b;"><?php echo esc_html( (string) $stats['pending'] ); ?></div><div class="cp-stat-label">Pending</div></div>
        <div class="cp-stat"><div class="cp-stat-val" style="color:#ef4444;"><?php echo esc_html( (string) $stats['expired'] ); ?></div><div class="cp-stat-label">Expired</div></div>
      </div>
    </div>
  </div>
</div>

<?php elseif ( 'coins' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">Currencies</div><div class="cp-section-sub">BTC and LTC are always free. License unlocks all 14 coins.</div></div>
  <?php if ( ! $has_license ) : ?>
  <div class="cp-notice cp-notice-amber">Free plan: Only Bitcoin and Litecoin available. <a href="<?php echo esc_url( admin_url( 'admin.php?page=chainpay-license' ) ); ?>">Get a license</a> to unlock all coins.</div>
  <?php endif; ?>
  <div class="cp-card" style="overflow:hidden;">
    <div class="cp-card-head">All Supported Currencies</div>
    <?php foreach ( $coins_all as $ck => $c ) :
      $is_en  = in_array( $ck, $enabled_coins, true );
      $is_lk  = ! $c['free'] && ! $has_license;
    ?>
    <div class="cp-coin-row<?php echo $is_lk ? ' cp-coin-locked' : ''; ?>">
      <div class="cp-coin-icon-sm" style="background:<?php echo esc_attr( $c['color'] ); ?>;"><?php echo esc_html( $c['icon'] ); ?></div>
      <div style="flex:1;">
        <div class="cp-coin-name"><?php echo esc_html( $c['name'] ); ?></div>
        <div class="cp-coin-sym"><?php echo esc_html( $c['symbol'] ); ?> &middot; <?php echo esc_html( $c['network'] ); ?></div>
      </div>
      <div>
        <?php if ( $is_lk ) : ?>
          <a href="<?php echo esc_url( admin_url( 'admin.php?page=chainpay-license' ) ); ?>" class="cp-lock-badge">&#128274; License</a>
        <?php else : ?>
          <label class="cp-toggle">
            <input type="checkbox" name="chainpay_enabled_coins[]" value="<?php echo esc_attr( $ck ); ?>" <?php checked( $is_en ); ?>>
            <span class="cp-toggle-slider"></span>
          </label>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<?php elseif ( 'wallets' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">Wallets &amp; xPub Keys</div></div>
  <div class="cp-notice cp-notice-amber"><strong>Security:</strong> Only enter your xPub (extended public key). Never your private key or seed phrase.</div>
  <?php
  foreach ( [ 'BTC', 'LTC', 'ETH', 'USDT_TRC20', 'XMR' ] as $wc ) :
    $cd = ChainPay_Coin_Registry::get( $wc );
    if ( ! $cd ) { continue; }
    $is_lk = ! $cd['free'] && ! $has_license;
    $xpub  = (string) get_option( 'chainpay_xpub_' . $wc, '' );
    $path  = (string) get_option( 'chainpay_xpub_path_' . $wc, $cd['derivation'] );
    $gap   = (int)    get_option( 'chainpay_xpub_gap_' . $wc, 20 );
  ?>
  <div class="cp-card<?php echo $is_lk ? ' cp-card-locked' : ''; ?>">
    <div class="cp-card-head" style="display:flex;align-items:center;justify-content:space-between;">
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:26px;height:26px;border-radius:50%;background:<?php echo esc_attr( $cd['color'] ); ?>;color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;"><?php echo esc_html( $cd['icon'] ); ?></div>
        <?php echo esc_html( $cd['name'] ); ?>
      </div>
      <?php if ( $is_lk ) : ?>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=chainpay-license' ) ); ?>" class="cp-lock-badge">Requires License</a>
      <?php elseif ( '' !== $xpub ) : ?>
        <span style="background:#f0fdf4;color:#166534;border-radius:20px;padding:3px 10px;font-size:11px;font-weight:700;">&#10003; Configured</span>
      <?php else : ?>
        <span style="background:#fef3c7;color:#92400e;border-radius:20px;padding:3px 10px;font-size:11px;font-weight:700;">Not configured</span>
      <?php endif; ?>
    </div>
    <?php if ( ! $is_lk ) : ?>
    <div class="cp-card-body">
      <div class="cp-field-row-2">
        <div class="cp-field-group">
          <label class="cp-label">Derivation Path</label>
          <select name="chainpay_xpub_path_<?php echo esc_attr( $wc ); ?>" class="cp-select">
            <?php
            $paths = [
                "m/84'/0'/0'"   => "m/84'/0'/0' — Native SegWit",
                "m/49'/0'/0'"   => "m/49'/0'/0' — SegWit Wrapped",
                "m/44'/0'/0'"   => "m/44'/0'/0' — Legacy",
                "m/44'/60'/0'"  => "m/44'/60'/0' — Ethereum/EVM",
                "m/44'/2'/0'"   => "m/44'/2'/0' — Litecoin",
                "m/44'/195'/0'" => "m/44'/195'/0' — Tron",
            ];
            foreach ( $paths as $pv => $pl ) : ?>
            <option value="<?php echo esc_attr( $pv ); ?>" <?php selected( $path, $pv ); ?>><?php echo esc_html( $pl ); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="cp-field-group">
          <label class="cp-label">Gap Limit</label>
          <input type="number" name="chainpay_xpub_gap_<?php echo esc_attr( $wc ); ?>" value="<?php echo esc_attr( (string) $gap ); ?>" min="1" max="100" class="cp-input" />
        </div>
      </div>
      <div class="cp-field-group" style="margin-bottom:12px;">
        <label class="cp-label">xPub / zPub Key</label>
        <input type="text" id="xpub_<?php echo esc_attr( $wc ); ?>" value="<?php echo esc_attr( $xpub ); ?>" placeholder="xpub6…" class="cp-input cp-input-mono" />
      </div>
      <div style="display:flex;gap:8px;">
        <button type="button" class="cp-btn cp-btn-primary" onclick="cpSaveXpub('<?php echo esc_js( $wc ); ?>')">Save xPub</button>
        <button type="button" class="cp-btn cp-btn-secondary" onclick="cpTestXpub('<?php echo esc_js( $wc ); ?>')">Test Derivation</button>
      </div>
      <div id="xpub-test-<?php echo esc_attr( $wc ); ?>" style="display:none;margin-top:10px;"></div>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<?php elseif ( 'payments' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">Payment Settings</div></div>
  <div class="cp-card">
    <div class="cp-card-head">Invoice &amp; Timing</div>
    <div class="cp-card-body">
      <div class="cp-field-row">
        <div class="cp-field-label">Invoice Timeout (minutes)</div>
        <div class="cp-field-input">
          <input type="number" name="chainpay_invoice_timeout" value="<?php echo esc_attr( (string) get_option( 'chainpay_invoice_timeout', 15 ) ); ?>" min="5" max="120" class="cp-input" style="width:100px;" />
          <p class="cp-field-help">Payment window before invoice expires.</p>
        </div>
      </div>
      <div class="cp-field-row">
        <div class="cp-field-label">Underpayment Tolerance (%)</div>
        <div class="cp-field-input">
          <input type="number" name="chainpay_underpayment_pct" value="<?php echo esc_attr( (string) get_option( 'chainpay_underpayment_pct', 1 ) ); ?>" min="0" max="10" step="0.1" class="cp-input" style="width:100px;" />
        </div>
      </div>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-head">Order Status Mapping</div>
    <div class="cp-card-body">
      <?php
      $wc_statuses = wc_get_order_statuses();
      $status_map  = [
          'chainpay_confirmed_status' => [ 'label' => 'On payment confirmed',       'default' => 'processing' ],
          'chainpay_pending_status'   => [ 'label' => 'On payment detected (unconf)','default' => 'on-hold' ],
          'chainpay_expired_status'   => [ 'label' => 'On invoice expired',          'default' => 'cancelled' ],
      ];
      foreach ( $status_map as $sk => $sd ) : ?>
      <div class="cp-field-row">
        <div class="cp-field-label"><?php echo esc_html( $sd['label'] ); ?></div>
        <div class="cp-field-input">
          <select name="<?php echo esc_attr( $sk ); ?>" class="cp-select">
            <?php foreach ( $wc_statuses as $sv => $sl ) :
              $sv_clean = str_replace( 'wc-', '', $sv ); ?>
            <option value="<?php echo esc_attr( $sv_clean ); ?>" <?php selected( get_option( $sk, $sd['default'] ), $sv_clean ); ?>><?php echo esc_html( $sl ); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-head">Feature Toggles</div>
    <div class="cp-card-body" style="padding:0 20px;">
      <?php
      $toggles = [
          [ 'key' => 'chainpay_smart_routing',      'title' => 'Smart Coin Routing',          'desc' => 'Auto-hide high-fee coins based on real-time network data.' ],
          [ 'key' => 'chainpay_underpayment_email', 'title' => 'Underpayment Recovery Emails', 'desc' => 'Auto-email customers who underpay with the remaining amount.' ],
      ];
      foreach ( $toggles as $tg ) : ?>
      <div class="cp-toggle-row">
        <div class="cp-toggle-info"><div class="cp-toggle-title"><?php echo esc_html( $tg['title'] ); ?></div><div class="cp-toggle-desc"><?php echo esc_html( $tg['desc'] ); ?></div></div>
        <label class="cp-toggle">
          <input type="checkbox" name="<?php echo esc_attr( $tg['key'] ); ?>" value="yes" <?php checked( get_option( $tg['key'], 'yes' ), 'yes' ); ?>>
          <span class="cp-toggle-slider"></span>
        </label>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php elseif ( 'checkout' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">Checkout Page</div></div>
  <div class="cp-card">
    <div class="cp-card-head">Layout Options</div>
    <div class="cp-card-body" style="padding:0 20px;">
      <?php
      $layout_opts = [
          [ 'key' => 'chainpay_show_qr',    'title' => 'Show QR Code',         'desc' => 'Display QR code on the Scan tab.' ],
          [ 'key' => 'chainpay_show_timer', 'title' => 'Show Countdown Timer', 'desc' => 'Display invoice expiry countdown.' ],
          [ 'key' => 'chainpay_show_rate',  'title' => 'Show Exchange Rate',   'desc' => 'Display current coin/fiat rate.' ],
          [ 'key' => 'chainpay_show_fee',   'title' => 'Show Recommended Fee', 'desc' => 'Display network fee at bottom.' ],
      ];
      foreach ( $layout_opts as $lo ) : ?>
      <div class="cp-toggle-row">
        <div class="cp-toggle-info"><div class="cp-toggle-title"><?php echo esc_html( $lo['title'] ); ?></div><div class="cp-toggle-desc"><?php echo esc_html( $lo['desc'] ); ?></div></div>
        <label class="cp-toggle">
          <input type="checkbox" name="<?php echo esc_attr( $lo['key'] ); ?>" value="yes" <?php checked( get_option( $lo['key'], 'yes' ), 'yes' ); ?>>
          <span class="cp-toggle-slider"></span>
        </label>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php elseif ( 'emails' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">Email Notifications</div></div>
  <div class="cp-card">
    <div class="cp-card-head">Customer Emails</div>
    <div class="cp-card-body" style="padding:0 20px;">
      <?php
      $email_opts = [
          [ 'key' => 'chainpay_email_on_detected',  'title' => 'Payment Detected (Unconfirmed)', 'desc' => 'Sent immediately when payment is seen on-chain.', 'default' => 'yes' ],
          [ 'key' => 'chainpay_email_on_confirmed',  'title' => 'Payment Confirmed',              'desc' => 'Sent after required blockchain confirmations.',   'default' => 'yes' ],
          [ 'key' => 'chainpay_underpayment_email',  'title' => 'Underpayment Notice',            'desc' => 'Email with remaining amount and address.',        'default' => 'yes' ],
          [ 'key' => 'chainpay_email_on_expired',    'title' => 'Invoice Expired',                'desc' => 'Sent when payment window expires.',               'default' => 'no' ],
      ];
      foreach ( $email_opts as $eo ) : ?>
      <div class="cp-toggle-row">
        <div class="cp-toggle-info"><div class="cp-toggle-title"><?php echo esc_html( $eo['title'] ); ?></div><div class="cp-toggle-desc"><?php echo esc_html( $eo['desc'] ); ?></div></div>
        <label class="cp-toggle">
          <input type="checkbox" name="<?php echo esc_attr( $eo['key'] ); ?>" value="yes" <?php checked( get_option( $eo['key'], $eo['default'] ), 'yes' ); ?>>
          <span class="cp-toggle-slider"></span>
        </label>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="cp-notice cp-notice-info">To edit email templates, go to <a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=email' ) ); ?>">WooCommerce &rarr; Settings &rarr; Emails</a>.</div>
</div>

<?php elseif ( 'webhooks' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">Webhooks &amp; IPN</div></div>
  <div class="cp-card">
    <div class="cp-card-head">Webhook Configuration</div>
    <div class="cp-card-body">
      <div class="cp-field-row">
        <div class="cp-field-label">Webhook URL</div>
        <div class="cp-field-input">
          <input type="url" name="chainpay_webhook_url" value="<?php echo esc_attr( (string) get_option( 'chainpay_webhook_url', '' ) ); ?>" class="cp-input" placeholder="https://yoursite.com/chainpay-ipn" />
          <p class="cp-field-help">ChainPay posts HMAC-SHA256 signed JSON events here on every payment update.</p>
        </div>
      </div>
      <div class="cp-field-row">
        <div class="cp-field-label">Webhook Secret</div>
        <div class="cp-field-input">
          <input type="text" name="chainpay_webhook_secret" value="<?php echo esc_attr( (string) get_option( 'chainpay_webhook_secret', '' ) ); ?>" class="cp-input cp-input-mono" placeholder="wsk_…" />
        </div>
      </div>
      <button type="button" class="cp-btn cp-btn-secondary" onclick="cpTestWebhook()">Send Test Webhook</button>
      <div id="cp-webhook-result" style="display:none;margin-top:10px;"></div>
    </div>
  </div>
</div>

<?php elseif ( 'routing' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">Smart Coin Routing</div><div class="cp-section-sub">Auto-hide high-fee coins to maximise checkout conversion.</div></div>
  <div class="cp-card">
    <div class="cp-card-head">Settings</div>
    <div class="cp-card-body" style="padding:0 20px;">
      <div class="cp-toggle-row">
        <div class="cp-toggle-info"><div class="cp-toggle-title">Enable Smart Routing</div><div class="cp-toggle-desc">Monitor network fees and automatically hide expensive coins.</div></div>
        <label class="cp-toggle">
          <input type="checkbox" name="chainpay_smart_routing" value="yes" <?php checked( get_option( 'chainpay_smart_routing', 'yes' ), 'yes' ); ?>>
          <span class="cp-toggle-slider"></span>
        </label>
      </div>
    </div>
  </div>
  <div class="cp-card">
    <div class="cp-card-head">ETH Gas Threshold</div>
    <div class="cp-card-body">
      <div class="cp-field-row">
        <div class="cp-field-label">Max ETH gas (USD)</div>
        <div class="cp-field-input">
          <input type="number" name="chainpay_eth_fee_threshold" value="<?php echo esc_attr( (string) get_option( 'chainpay_eth_fee_threshold', 30 ) ); ?>" min="0" step="1" class="cp-input" style="width:100px;" />
          <p class="cp-field-help">Hide ETH/ERC-20 coins when gas exceeds this USD amount. Set 0 to always show.</p>
        </div>
      </div>
    </div>
  </div>
</div>

<?php elseif ( 'license' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">License</div></div>
  <?php if ( $has_license ) : ?>
  <div class="cp-notice cp-notice-green">&#10003; License Active &mdash; Plan: <?php echo esc_html( ucfirst( $lic['plan'] ) ); ?><?php echo '' !== $lic['expires'] ? ' &middot; Expires: ' . esc_html( $lic['expires'] ) : ''; ?></div>
  <div class="cp-card">
    <div class="cp-card-head">Current License</div>
    <div class="cp-card-body">
      <p style="font-family:monospace;background:#f8f8f8;padding:8px 12px;border-radius:6px;font-size:13px;"><?php echo esc_html( $lic['key'] ); ?></p>
      <button type="button" class="cp-btn cp-btn-danger" onclick="cpRevokeLicense()">Revoke License</button>
    </div>
  </div>
  <?php else : ?>
  <div class="cp-card" style="border:2px solid #f7931a;">
    <div class="cp-card-head" style="background:#fff7ed;">Activate License Key</div>
    <div class="cp-card-body">
      <div class="cp-field-row">
        <div class="cp-field-label">License Key</div>
        <div class="cp-field-input">
          <input type="text" id="cp_license_key_input" placeholder="cp_lic_…" class="cp-input cp-input-mono" />
          <p class="cp-field-help">Purchase at <a href="https://chainpay.io/pricing" target="_blank">chainpay.io/pricing</a> &mdash; $49/year &middot; All 14 coins &middot; All features.</p>
        </div>
      </div>
      <div style="display:flex;gap:10px;">
        <button type="button" class="cp-btn cp-btn-primary" onclick="cpVerifyLicense()">Activate License</button>
        <a href="https://chainpay.io/pricing" target="_blank" class="cp-btn cp-btn-secondary" style="text-decoration:none;">Buy License &rarr;</a>
      </div>
      <div id="cp-license-result" style="display:none;margin-top:12px;"></div>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php elseif ( 'logs' === $tab ) : ?>
<div class="cp-section">
  <div class="cp-section-header"><div class="cp-section-title">Logs</div></div>
  <div class="cp-card">
    <div class="cp-card-head">Recent Invoices</div>
    <div class="cp-card-body">
      <?php
      global $wpdb;
      $rows = $wpdb->get_results(
          "SELECT * FROM {$wpdb->prefix}chainpay_invoices ORDER BY created_at DESC LIMIT 25",
          ARRAY_A
      );
      $sc = [ 'confirmed' => '#4caf50', 'pending' => '#f59e0b', 'detected' => '#3b82f6', 'expired' => '#ef4444', 'underpaid' => '#dc2626' ];
      if ( $rows ) : ?>
      <table style="width:100%;border-collapse:collapse;font-size:12px;">
        <thead><tr style="border-bottom:2px solid #e8e8e8;">
          <th style="padding:6px 8px;text-align:left;color:#888;">Time</th>
          <th style="padding:6px 8px;text-align:left;color:#888;">Order</th>
          <th style="padding:6px 8px;text-align:left;color:#888;">Coin</th>
          <th style="padding:6px 8px;text-align:left;color:#888;">Amount</th>
          <th style="padding:6px 8px;text-align:left;color:#888;">Status</th>
          <th style="padding:6px 8px;text-align:left;color:#888;">TX</th>
        </tr></thead>
        <tbody>
        <?php foreach ( $rows as $row ) :
          $c_color = isset( $sc[ $row['status'] ] ) ? $sc[ $row['status'] ] : '#888'; ?>
          <tr style="border-bottom:1px solid #f5f5f5;">
            <td style="padding:7px 8px;color:#888;"><?php echo esc_html( date_i18n( 'M j H:i', strtotime( $row['created_at'] ) ) ); ?></td>
            <td style="padding:7px 8px;"><a href="<?php echo esc_url( admin_url( 'post.php?post=' . $row['order_id'] . '&action=edit' ) ); ?>">#<?php echo esc_html( (string) $row['order_id'] ); ?></a></td>
            <td style="padding:7px 8px;font-weight:700;"><?php echo esc_html( $row['coin'] ); ?></td>
            <td style="padding:7px 8px;font-family:monospace;"><?php echo esc_html( $row['amount_crypto'] . ' ' . $row['coin'] ); ?></td>
            <td style="padding:7px 8px;"><span style="color:<?php echo esc_attr( $c_color ); ?>;font-weight:700;"><?php echo esc_html( ucfirst( $row['status'] ) ); ?></span></td>
            <td style="padding:7px 8px;font-family:monospace;font-size:10px;color:#888;"><?php echo ( isset( $row['tx_hash'] ) && '' !== $row['tx_hash'] ) ? esc_html( substr( $row['tx_hash'], 0, 12 ) ) . '&hellip;' : '&mdash;'; ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php else : ?>
      <p style="color:#888;text-align:center;padding:20px 0;">No invoices yet.</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ( ! in_array( $tab, [ 'logs', 'license' ], true ) ) : ?>
<div class="cp-save-bar">
  <button type="button" id="cp-save-btn" class="cp-btn cp-btn-primary cp-btn-large" onclick="cpSaveSettings()">Save Settings</button>
  <span id="cp-save-msg" style="display:none;font-size:13px;font-weight:600;margin-left:12px;"></span>
</div>
<?php endif; ?>

</form>
</div><!-- /cp-admin-content -->
</div><!-- /wrap -->
