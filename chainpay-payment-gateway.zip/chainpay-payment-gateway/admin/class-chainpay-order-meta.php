<?php
defined( 'ABSPATH' ) || exit;

class ChainPay_Order_Meta {

    public function __construct() {
        add_action( 'add_meta_boxes',                       [ $this, 'add_meta_box' ] );
        add_filter( 'woocommerce_order_list_table_columns', [ $this, 'add_columns' ] );
        add_action( 'woocommerce_order_list_table_column_content', [ $this, 'render_column' ], 10, 3 );
    }

    public function add_meta_box(): void {
        foreach ( [ 'shop_order', 'woocommerce_page_wc-orders' ] as $screen ) {
            add_meta_box(
                'chainpay_order_details',
                'ChainPay Payment Details',
                [ $this, 'render_meta_box' ],
                $screen,
                'side',
                'high'
            );
        }
    }

    public function render_meta_box( $post_or_order ): void {
        if ( $post_or_order instanceof WC_Order ) {
            $order = $post_or_order;
        } else {
            $order = wc_get_order( $post_or_order->ID );
        }

        if ( ! $order || 'chainpay' !== $order->get_payment_method() ) {
            echo '<p style="color:#999;font-size:12px;">Not a ChainPay order.</p>';
            return;
        }

        $this->render_panel( $order );
    }

    private function render_panel( $order ): void {
        $coin_key  = (string) $order->get_meta( '_chainpay_coin' );
        $coin      = '' !== $coin_key ? ChainPay_Coin_Registry::get( $coin_key ) : null;
        $status    = (string) $order->get_meta( '_chainpay_status' );
        $status    = '' !== $status ? $status : 'pending';
        $tx_hash   = (string) $order->get_meta( '_chainpay_tx_hash' );
        $address   = (string) $order->get_meta( '_chainpay_address' );
        $crypto    = (string) $order->get_meta( '_chainpay_amount_crypto' );
        $fiat      = (float)  $order->get_meta( '_chainpay_amount_fiat' );
        $rate      = (float)  $order->get_meta( '_chainpay_exchange_rate' );
        $expires   = (string) $order->get_meta( '_chainpay_expires_at' );
        $confs     = (int)    $order->get_meta( '_chainpay_confirmations' );
        $inv_id    = (string) $order->get_meta( '_chainpay_invoice_id' );
        $network   = (string) $order->get_meta( '_chainpay_network' );
        $received  = (string) $order->get_meta( '_chainpay_received_amount' );

        $color     = $coin ? $coin['color']   : '#f7931a';
        $symbol    = $coin ? $coin['symbol']  : $coin_key;
        $icon      = $coin ? $coin['icon']    : '#';
        $name      = $coin ? $coin['name']    : $coin_key;
        $req_confs = $coin ? $coin['confirms']: 1;

        $sc = [
            'pending'   => [ 'bg' => '#fffbeb', 'color' => '#92400e', 'label' => 'Pending' ],
            'detected'  => [ 'bg' => '#eff6ff', 'color' => '#1e40af', 'label' => 'Detected' ],
            'confirmed' => [ 'bg' => '#f0fdf4', 'color' => '#166534', 'label' => 'Confirmed' ],
            'expired'   => [ 'bg' => '#fef2f2', 'color' => '#991b1b', 'label' => 'Expired' ],
            'underpaid' => [ 'bg' => '#fff5f5', 'color' => '#c0392b', 'label' => 'Underpaid' ],
        ];
        $s = isset( $sc[ $status ] ) ? $sc[ $status ] : $sc['pending'];
        ?>
        <style>
        .cp-box{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:13px;}
        .cp-badge{display:inline-block;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;margin-bottom:12px;}
        .cp-amt-row{display:flex;align-items:center;gap:10px;background:#f8f8f8;border-radius:8px;padding:10px;margin-bottom:12px;}
        .cp-coin{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:800;color:#fff;flex-shrink:0;}
        .cp-crypto{font-size:15px;font-weight:800;font-family:monospace;}
        .cp-fiat{font-size:11px;color:#888;margin-top:2px;}
        .cp-tbl{width:100%;border-collapse:collapse;margin-bottom:12px;}
        .cp-tbl td{padding:6px 0;font-size:12px;border-bottom:1px solid #f5f5f5;vertical-align:top;}
        .cp-tbl .k{color:#888;width:80px;}
        .cp-tbl .v{font-weight:500;word-break:break-word;}
        .cp-lbl{font-size:10px;text-transform:uppercase;letter-spacing:.6px;color:#999;font-weight:700;margin:10px 0 5px;}
        .cp-copy-row{display:flex;align-items:center;gap:6px;background:#f8f8f8;border:1px solid #e8e8e8;border-radius:6px;padding:7px 9px;margin-bottom:4px;}
        .cp-addr{font-family:monospace;font-size:10px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
        .cp-copy{background:#e8f5e9;color:#2e7d32;border:none;border-radius:4px;padding:3px 9px;font-size:11px;font-weight:600;cursor:pointer;}
        .cp-copy:hover{background:#2e7d32;color:#fff;}
        .cp-explorer{display:block;font-size:11px;color:#2563eb;text-decoration:none;margin-bottom:8px;}
        .cp-explorer:hover{text-decoration:underline;}
        .cp-alert{border-radius:6px;padding:8px 10px;font-size:11px;line-height:1.5;margin-bottom:8px;}
        .cp-alert-red{background:#fef2f2;border:1px solid #fecaca;color:#991b1b;}
        .cp-actions{border-top:1px solid #f0f0f0;padding-top:10px;margin-top:10px;}
        .cp-actions-title{font-size:10px;text-transform:uppercase;letter-spacing:.5px;color:#999;margin-bottom:7px;font-weight:700;}
        .cp-btn-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px;}
        .cp-action{background:#fff;border:1px solid #e0e0e0;border-radius:6px;padding:6px;font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;text-align:center;text-decoration:none;display:block;transition:background .12s;color:#333;}
        .cp-action:hover{background:#f5f5f5;}
        .cp-foot{text-align:center;font-size:10px;color:#ccc;margin-top:10px;}
        </style>
        <div class="cp-box">
            <span class="cp-badge" style="background:<?php echo esc_attr( $s['bg'] ); ?>;color:<?php echo esc_attr( $s['color'] ); ?>;">
                <?php echo esc_html( $s['label'] ); ?>
            </span>
            <div class="cp-amt-row">
                <div class="cp-coin" style="background:<?php echo esc_attr( $color ); ?>;"><?php echo esc_html( $icon ); ?></div>
                <div>
                    <div class="cp-crypto"><?php echo esc_html( $crypto ); ?> <?php echo esc_html( $symbol ); ?></div>
                    <div class="cp-fiat"><?php echo wc_price( $fiat, [ 'currency' => $order->get_currency() ] ); ?> &middot; 1<?php echo esc_html( $symbol ); ?>=$<?php echo esc_html( number_format( $rate, 2 ) ); ?></div>
                </div>
            </div>
            <table class="cp-tbl">
                <tr><td class="k">Coin</td><td class="v"><?php echo esc_html( $name ); ?> (<?php echo esc_html( $symbol ); ?>)</td></tr>
                <tr><td class="k">Network</td><td class="v"><?php echo esc_html( '' !== $network ? $network : '—' ); ?></td></tr>
                <tr>
                    <td class="k">Confirms</td>
                    <td class="v">
                        <span style="background:<?php echo $confs >= $req_confs ? '#f0fdf4' : '#fffbeb'; ?>;color:<?php echo $confs >= $req_confs ? '#166534' : '#92400e'; ?>;border-radius:20px;padding:2px 7px;font-size:11px;font-weight:700;">
                            <?php echo esc_html( $confs . '/' . $req_confs ); ?>
                        </span>
                    </td>
                </tr>
                <?php if ( '' !== $expires ) : ?>
                <tr><td class="k">Expires</td><td class="v" style="font-family:monospace;font-size:10px;"><?php echo esc_html( $expires ); ?></td></tr>
                <?php endif; ?>
                <?php if ( '' !== $inv_id ) : ?>
                <tr><td class="k">Invoice</td><td class="v" style="font-family:monospace;font-size:10px;"><?php echo esc_html( $inv_id ); ?></td></tr>
                <?php endif; ?>
            </table>

            <?php if ( '' !== $address ) : ?>
            <div class="cp-lbl">Address</div>
            <div class="cp-copy-row">
                <div class="cp-addr"><?php echo esc_html( $address ); ?></div>
                <button class="cp-copy" data-copy="<?php echo esc_attr( $address ); ?>">Copy</button>
            </div>
            <?php endif; ?>

            <?php if ( '' !== $tx_hash ) : ?>
            <div class="cp-lbl">TX Hash</div>
            <div class="cp-copy-row">
                <div class="cp-addr"><?php echo esc_html( $tx_hash ); ?></div>
                <button class="cp-copy" data-copy="<?php echo esc_attr( $tx_hash ); ?>">Copy</button>
            </div>
            <?php if ( $coin ) : ?>
            <a class="cp-explorer" href="<?php echo esc_url( self::explorer_url( $coin_key, $tx_hash ) ); ?>" target="_blank">View on explorer &nearr;</a>
            <?php endif; ?>
            <?php endif; ?>

            <?php if ( 'underpaid' === $status && '' !== $received ) : ?>
            <div class="cp-alert cp-alert-red">Underpayment: Received <strong><?php echo esc_html( $received ); ?> <?php echo esc_html( $symbol ); ?></strong>, expected <strong><?php echo esc_html( $crypto ); ?> <?php echo esc_html( $symbol ); ?></strong></div>
            <?php endif; ?>

            <div class="cp-actions">
                <div class="cp-actions-title">Admin Actions</div>
                <div class="cp-btn-grid">
                    <button class="cp-action" onclick="cpResendEmail(<?php echo (int) $order->get_id(); ?>,'confirmed')">Email Customer</button>
                    <?php if ( '' !== $tx_hash ) : ?>
                    <button class="cp-action" onclick="cpResendWebhook('<?php echo esc_js( $inv_id ); ?>')">Resend Webhook</button>
                    <?php endif; ?>
                    <a class="cp-action" href="<?php echo esc_url( admin_url( 'admin.php?page=chainpay-logs' ) ); ?>">View Logs</a>
                </div>
            </div>
            <div class="cp-foot">ChainPay v<?php echo esc_html( CHAINPAY_VERSION ); ?></div>
        </div>
        <script>
        (function(){
            var nonce = '<?php echo esc_js( wp_create_nonce( 'chainpay_admin_nonce' ) ); ?>';
            window.cpResendEmail = function(id, type) {
                if (!confirm('Resend email to customer?')) return;
                jQuery.post(ajaxurl, { action:'chainpay_resend_email', nonce:nonce, order_id:id, email_type:type },
                    function(r){ alert(r.success ? 'Email sent!' : 'Error: '+(r.data||'Unknown')); });
            };
            window.cpResendWebhook = function(invId) {
                if (!confirm('Resend webhook?')) return;
                jQuery.post(ajaxurl, { action:'chainpay_test_webhook', nonce:nonce, invoice_id:invId },
                    function(r){ alert(r.success ? 'Sent!' : 'Error: '+(r.data||'Unknown')); });
            };
            document.querySelectorAll('.cp-copy').forEach(function(btn){
                btn.addEventListener('click', function(){
                    var t = this.getAttribute('data-copy');
                    if (navigator.clipboard) { navigator.clipboard.writeText(t); }
                    var orig = this.textContent; this.textContent = 'Copied!';
                    var b = this; setTimeout(function(){ b.textContent = orig; }, 1800);
                });
            });
        })();
        </script>
        <?php
    }

    private static function explorer_url( string $coin_key, string $tx ): string {
        $map = [
            'BTC'        => 'https://blockstream.info/tx/' . $tx,
            'LTC'        => 'https://blockchair.com/litecoin/transaction/' . $tx,
            'ETH'        => 'https://etherscan.io/tx/' . $tx,
            'USDT_TRC20' => 'https://tronscan.org/#/transaction/' . $tx,
            'USDT_ERC20' => 'https://etherscan.io/tx/' . $tx,
            'USDC'       => 'https://etherscan.io/tx/' . $tx,
            'BNB'        => 'https://bscscan.com/tx/' . $tx,
            'DOGE'       => 'https://dogechain.info/tx/' . $tx,
            'SOL'        => 'https://solscan.io/tx/' . $tx,
            'MATIC'      => 'https://polygonscan.com/tx/' . $tx,
            'XMR'        => 'https://localmonero.co/blocks/tx/' . $tx,
            'TRX'        => 'https://tronscan.org/#/transaction/' . $tx,
            'AVAX'       => 'https://snowtrace.io/tx/' . $tx,
            'ARB'        => 'https://arbiscan.io/tx/' . $tx,
        ];
        return isset( $map[ $coin_key ] ) ? $map[ $coin_key ] : '#';
    }

    // ── ORDER LIST COLUMN ──────────────────────────────────────────────────
    public function add_columns( array $columns ): array {
        $new = [];
        foreach ( $columns as $k => $v ) {
            $new[ $k ] = $v;
            if ( 'order_status' === $k ) {
                $new['chainpay_coin'] = 'Coin';
            }
        }
        return $new;
    }

    public function render_column( string $column, $order_id, $order ): void {
        if ( 'chainpay_coin' !== $column ) {
            return;
        }
        if ( ! ( $order instanceof WC_Order ) ) {
            $order = wc_get_order( $order_id );
        }
        if ( ! $order || 'chainpay' !== $order->get_payment_method() ) {
            return;
        }
        $ck   = (string) $order->get_meta( '_chainpay_coin' );
        $coin = '' !== $ck ? ChainPay_Coin_Registry::get( $ck ) : null;
        if ( $coin ) {
            echo '<span style="background:' . esc_attr( $coin['color'] ) . '22;color:' . esc_attr( $coin['color'] ) . ';border-radius:20px;padding:2px 8px;font-size:11px;font-weight:700;">';
            echo esc_html( $coin['icon'] ) . ' ' . esc_html( $coin['symbol'] );
            echo '</span>';
        }
    }
}
