/* global jQuery, chainpay_params, QRCode */
(function ($) {
    'use strict';

    var p          = chainpay_params;
    var invoice    = null;
    var qrInstance = null;
    var timerInt   = null;
    var pollInt    = null;
    var coins      = p.coins || {};

    /* ── INIT ─────────────────────────────────────────────────────────── */
    $(document).ready(function () {
        if (!p.order_id) return;

        // Pick first available coin
        var firstCoin = Object.keys(coins)[0] || 'BTC';
        selectCoin(firstCoin);

        // Tab switching
        $(document).on('click', '.cp-tab-btn', function () {
            var tab = $(this).data('tab');
            $('.cp-tab-btn').removeClass('active');
            $(this).addClass('active');
            $('.cp-tab-pane').removeClass('active');
            $('#cp-tab-' + tab).addClass('active');
        });

        // Coin selector toggle
        $(document).on('click', '.cp-coin-selector', function () {
            openSheet();
        });

        // Sheet coin click
        $(document).on('click', '.cp-sheet-coin:not(.locked)', function () {
            var ck = $(this).data('coin');
            closeSheet();
            selectCoin(ck);
        });

        // Locked coin
        $(document).on('click', '.cp-sheet-coin.locked', function () {
            closeSheet();
            openLicenseModal();
        });

        // Sheet backdrop click
        $(document).on('click', '.cp-coin-sheet', function (e) {
            if ($(e.target).is('.cp-coin-sheet')) closeSheet();
        });

        // Copy buttons
        $(document).on('click', '.cp-copy-btn', function () {
            var val = $(this).data('copy') || $(this).closest('.cp-copy-row').find('.cp-copy-val').text().trim();
            copyToClipboard(val, this);
        });

        // Modal close
        $(document).on('click', '.cp-modal-close, .cp-modal-overlay', function (e) {
            if ($(e.target).is('.cp-modal-overlay') || $(e.target).is('.cp-modal-close')) {
                closeLicenseModal();
            }
        });
    });

    /* ── SELECT COIN ──────────────────────────────────────────────────── */
    function selectCoin(coinKey) {
        var coin = p.all_coins[coinKey];
        if (!coin) return;

        // Update selector
        $('.cp-coin-dot').css('background', coin.color).text(coin.icon || '');
        $('.cp-coin-label').text(coin.name);
        $('.cp-coin-network').text(coin.symbol + ' · ' + coin.network);

        // Reset QR
        showQrLoading();

        // Fetch / create invoice
        $.post(p.ajax_url, {
            action:    'chainpay_get_invoice',
            nonce:     p.nonce,
            order_id:  p.order_id,
            order_key: p.order_key,
            coin:      coinKey
        }, function (r) {
            if (r.success) {
                invoice = r.data;
                renderInvoice(invoice);
                startTimer(invoice.expires_at);
                startPolling(invoice.invoice_id);
            } else {
                showQrError(r.data || 'Error creating invoice.');
            }
        });
    }

    /* ── RENDER INVOICE ───────────────────────────────────────────────── */
    function renderInvoice(inv) {
        var coin = p.all_coins[inv.coin] || {};

        // Amounts
        var cryptoAmt = parseFloat(inv.amount_crypto).toFixed(8).replace(/\.?0+$/, '');
        $('.cp-crypto-amount').text(cryptoAmt + ' ' + (coin.symbol || inv.coin));
        $('.cp-rate').text('1 ' + (coin.symbol || '') + ' = $' + parseFloat(inv.exchange_rate).toLocaleString());

        // QR
        renderQR(inv.uri || inv.address, coin);

        // Wallet link
        $('.cp-open-wallet').attr('href', inv.uri || 'javascript:void(0)');

        // Copy tab
        $('#cp-copy-amount .cp-copy-val').text(inv.amount_crypto);
        $('#cp-copy-amount .cp-copy-btn').attr('data-copy', inv.amount_crypto);
        $('#cp-copy-address .cp-copy-val').text(inv.address);
        $('#cp-copy-address .cp-copy-btn').attr('data-copy', inv.address);
        if (inv.uri) {
            $('#cp-copy-link .cp-copy-val').text(inv.uri);
            $('#cp-copy-link .cp-copy-btn').attr('data-copy', inv.uri);
        }

        // Rec fee
        var fee = coin.rec_fee || '';
        if (fee) { $('.cp-fee-text').text(fee); }

        // Coin overlay
        $('.cp-qr-coin-overlay').css('background', coin.color || '#f7931a').text(coin.icon || '');
    }

    /* ── QR ───────────────────────────────────────────────────────────── */
    function renderQR(data, coin) {
        var el = document.getElementById('cp-qr-canvas');
        if (!el) return;
        $(el).empty();
        if (typeof QRCode === 'undefined') { showQrLoading(); return; }

        try {
            qrInstance = new QRCode(el, {
                text:           data,
                width:          170,
                height:         170,
                colorDark:      '#000',
                colorLight:     '#fff',
                correctLevel:   QRCode.CorrectLevel.M
            });
        } catch (e) {
            showQrLoading();
        }
    }

    function showQrLoading() {
        var el = document.getElementById('cp-qr-canvas');
        if (el) { $(el).html('<div class="cp-qr-loading">Loading…</div>'); }
    }

    function showQrError(msg) {
        var el = document.getElementById('cp-qr-canvas');
        if (el) { $(el).html('<div class="cp-qr-loading" style="color:#f87171;">' + msg + '</div>'); }
    }

    /* ── TIMER ────────────────────────────────────────────────────────── */
    function startTimer(expiresAt) {
        clearInterval(timerInt);
        timerInt = setInterval(function () {
            var diff = Math.floor((new Date(expiresAt) - new Date()) / 1000);
            var el   = document.querySelector('.cp-timer');
            if (!el) return;
            if (diff <= 0) {
                clearInterval(timerInt);
                $(el).text('Expired').removeClass('warning critical');
                showState('expired');
                return;
            }
            var m = String(Math.floor(diff / 60)).padStart(2, '0');
            var s = String(diff % 60).padStart(2, '0');
            $(el).text(m + ':' + s);
            $(el).toggleClass('warning',  diff <= 120 && diff > 60);
            $(el).toggleClass('critical', diff <= 60);
        }, 1000);
    }

    /* ── POLL ─────────────────────────────────────────────────────────── */
    function startPolling(invoiceId) {
        clearInterval(pollInt);
        pollInt = setInterval(function () {
            $.post(p.ajax_url, {
                action:     'chainpay_poll_status',
                nonce:      p.nonce,
                invoice_id: invoiceId
            }, function (r) {
                if (!r.success) return;
                var d = r.data;
                if (d.status === 'detected') {
                    updateStatusBar('detected', 'Payment Detected — awaiting confirmation…');
                } else if (d.status === 'confirmed') {
                    clearInterval(pollInt);
                    clearInterval(timerInt);
                    showState('confirmed');
                    if (d.redirect_url) {
                        setTimeout(function () { window.location.href = d.redirect_url; }, 2500);
                    }
                } else if (d.status === 'expired') {
                    clearInterval(pollInt);
                    clearInterval(timerInt);
                    showState('expired');
                }
            });
        }, 8000);
    }

    /* ── STATE DISPLAY ────────────────────────────────────────────────── */
    function showState(state) {
        var states = {
            confirmed: { icon: '✅', title: 'Payment Confirmed!', sub: 'Your order is being processed. Redirecting…' },
            expired:   { icon: '⏱',  title: 'Invoice Expired',    sub: 'Please place a new order.' },
            detected:  { icon: '⏳', title: 'Payment Detected…',  sub: 'Waiting for blockchain confirmation.' }
        };
        var s = states[state] || states.detected;
        var html = '<div class="cp-state-overlay active"><div class="cp-state-icon">' + s.icon + '</div><div class="cp-state-title">' + s.title + '</div><div class="cp-state-sub">' + s.sub + '</div></div>';
        $('.cp-tab-pane.active').html(html);
        updateStatusBar(state, s.title);
    }

    function updateStatusBar(state, text) {
        var bar = $('.cp-status-bar');
        bar.removeClass('detected confirmed expired').addClass(state);
        bar.find('.cp-status-text').text(text);
    }

    /* ── COIN SHEET ───────────────────────────────────────────────────── */
    function openSheet() {
        var allCoins = p.all_coins || {};
        var freeKeys = p.free_coins || [];
        var hasLic   = p.has_license;
        var html     = '<div class="cp-coin-sheet open"><div class="cp-coin-sheet-inner">';
        html += '<div class="cp-sheet-handle"></div>';
        html += '<div class="cp-sheet-title">Select Currency</div>';

        for (var ck in allCoins) {
            var c      = allCoins[ck];
            var isLocked = !hasLic && freeKeys.indexOf(ck) === -1;
            var isSel  = invoice && invoice.coin === ck;
            var cls    = 'cp-sheet-coin' + (isLocked ? ' locked' : '') + (isSel ? ' selected' : '');
            html += '<div class="' + cls + '" data-coin="' + ck + '">';
            html += '<div class="cp-coin-dot" style="background:' + c.color + ';">' + (c.icon || '') + '</div>';
            html += '<div class="cp-sheet-coin-info"><div class="cp-sheet-coin-name">' + c.name + '</div><div class="cp-sheet-coin-net">' + c.symbol + ' · ' + c.network + '</div></div>';
            if (isLocked) { html += '<span class="cp-sheet-lock">🔒 License</span>'; }
            if (isSel) { html += '<span style="color:#4ade80;font-weight:800;font-size:16px;">✓</span>'; }
            html += '</div>';
        }
        html += '</div></div>';
        $('body').append(html);
    }

    function closeSheet() { $('.cp-coin-sheet').remove(); }

    /* ── LICENSE MODAL ────────────────────────────────────────────────── */
    function openLicenseModal() {
        var html = '<div class="cp-modal-overlay open"><div class="cp-modal">';
        html += '<div class="cp-modal-icon">🔒</div>';
        html += '<div class="cp-modal-title">License Required</div>';
        html += '<div class="cp-modal-desc">Unlock all 14 cryptocurrencies for just <strong>$49/year</strong>. BTC and LTC are always free.</div>';
        html += '<a class="cp-modal-cta" href="' + (p.license_url || 'https://chainpay.io/pricing') + '" target="_blank">Get License — $49/yr</a>';
        html += '<button class="cp-modal-close">Continue with BTC / LTC</button>';
        html += '</div></div>';
        $('body').append(html);
    }

    function closeLicenseModal() { $('.cp-modal-overlay').remove(); }

    /* ── COPY ─────────────────────────────────────────────────────────── */
    function copyToClipboard(text, btn) {
        var origText = $(btn).text();
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function () {
                $(btn).text('Copied!').addClass('copied');
                setTimeout(function () { $(btn).text(origText).removeClass('copied'); }, 1800);
            });
        } else {
            var ta = document.createElement('textarea');
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            $(btn).text('Copied!').addClass('copied');
            setTimeout(function () { $(btn).text(origText).removeClass('copied'); }, 1800);
        }
    }

}(jQuery));
