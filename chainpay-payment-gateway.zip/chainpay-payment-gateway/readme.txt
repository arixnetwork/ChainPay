=== ChainPay Payment Gateway ===
Contributors: chainpay
Tags: bitcoin, crypto, woocommerce, payment, gateway
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Accept Bitcoin, Litecoin and 12+ cryptocurrencies in WooCommerce. Non-custodial, xPub HD wallet derivation.

== Description ==
ChainPay lets you accept crypto payments directly to your own wallets. No custodian, no KYC.

Free plan: Bitcoin (BTC) + Litecoin (LTC).
Pro License ($49/yr): All 14 coins including ETH, USDT, USDC, XMR, BNB, DOGE, SOL, MATIC, TRX, AVAX, ARB.

== Installation ==
1. Upload to /wp-content/plugins/
2. Activate in WP Admin
3. Go to WooCommerce > Settings > Payments > ChainPay
4. Configure your xPub keys in ChainPay > Wallets

== Changelog ==
= 1.0.0 =
* Initial release
