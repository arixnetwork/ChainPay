<?php defined( 'ABSPATH' ) || exit; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( get_bloginfo( 'name' ) ); ?> — Pay with Crypto</title>
<?php wp_head(); ?>
</head>
<body class="chainpay-page">
<?php
// Validate order
$cp_order_id  = isset( $_GET['order_id'] )  ? absint( $_GET['order_id'] )                        : 0;
$cp_order_key = isset( $_GET['order_key'] ) ? sanitize_text_field( $_GET['order_key'] )           : '';
$cp_order     = wc_get_order( $cp_order_id );

if ( ! $cp_order || ! hash_equals( $cp_order->get_order_key(), $cp_order_key ) ) {
    wp_die( 'Invalid payment link.', 'ChainPay', [ 'response' => 404 ] );
}

$cp_timeout = (int) get_option( 'chainpay_invoice_timeout', 15 );
$cp_show_qr    = 'yes' === get_option( 'chainpay_show_qr', 'yes' );
$cp_show_timer = 'yes' === get_option( 'chainpay_show_timer', 'yes' );
$cp_show_rate  = 'yes' === get_option( 'chainpay_show_rate', 'yes' );
$cp_show_fee   = 'yes' === get_option( 'chainpay_show_fee', 'yes' );
$cp_store      = get_bloginfo( 'name' );
?>

<div class="cp-checkout-card">

    <!-- STATUS BAR -->
    <div class="cp-status-bar">
        <div class="cp-spinner" id="cp-spinner"></div>
        <div class="cp-status-text" id="cp-status-text">Awaiting Payment&hellip;</div>
        <?php if ( $cp_show_timer ) : ?>
        <div class="cp-timer" id="cp-timer"><?php echo esc_html( sprintf( '%02d:00', $cp_timeout ) ); ?></div>
        <?php endif; ?>
    </div>

    <!-- MERCHANT ROW -->
    <div class="cp-merchant-row">
        <div>
            <div class="cp-merchant-name"><?php echo esc_html( $cp_store ); ?></div>
            <div style="font-size:12px;color:#888;">Order #<?php echo esc_html( $cp_order->get_order_number() ); ?></div>
        </div>
        <div class="cp-amount-block">
            <div class="cp-crypto-amount" id="cp-crypto-amount">—</div>
            <?php if ( $cp_show_rate ) : ?>
            <div class="cp-rate" id="cp-rate"></div>
            <?php endif; ?>
        </div>
    </div>

    <!-- COIN SELECTOR -->
    <div class="cp-coin-selector" id="cp-coin-selector">
        <div class="cp-selected-coin">
            <div class="cp-coin-dot" id="cp-coin-dot" style="background:#f7931a;">&#8383;</div>
            <div>
                <div class="cp-coin-label" id="cp-coin-label">Loading&hellip;</div>
                <div class="cp-coin-network" id="cp-coin-network"></div>
            </div>
        </div>
        <span class="cp-chevron" id="cp-chevron">&#8964;</span>
        <span style="font-size:12px;color:#888;">Change</span>
    </div>

    <!-- TABS -->
    <?php if ( $cp_show_qr ) : ?>
    <div class="cp-tabs">
        <button class="cp-tab-btn active" data-tab="scan">Scan</button>
        <button class="cp-tab-btn" data-tab="copy">Copy</button>
    </div>
    <?php endif; ?>

    <!-- SCAN TAB -->
    <?php if ( $cp_show_qr ) : ?>
    <div class="cp-tab-pane active" id="cp-tab-scan">
        <div class="cp-qr-wrap">
            <div id="cp-qr-canvas"><div class="cp-qr-loading">Generating QR&hellip;</div></div>
            <div class="cp-qr-coin-overlay" id="cp-qr-overlay" style="background:#f7931a;">&#8383;</div>
        </div>
        <a href="#" class="cp-open-wallet" id="cp-open-wallet">Open in Wallet</a>
    </div>
    <?php endif; ?>

    <!-- COPY TAB (or main pane if no QR) -->
    <div class="cp-tab-pane<?php echo ! $cp_show_qr ? ' active' : ''; ?>" id="cp-tab-copy">
        <div class="cp-copy-item" id="cp-copy-amount">
            <div class="cp-copy-label">Amount</div>
            <div class="cp-copy-row">
                <div class="cp-copy-val">—</div>
                <button class="cp-copy-btn" data-copy="">Copy</button>
            </div>
        </div>
        <div class="cp-divider">◆</div>
        <div class="cp-copy-item" id="cp-copy-address">
            <div class="cp-copy-label">Address</div>
            <div class="cp-copy-row">
                <div class="cp-copy-val">—</div>
                <button class="cp-copy-btn" data-copy="">Copy</button>
            </div>
        </div>
        <div class="cp-divider">◆</div>
        <div class="cp-copy-item" id="cp-copy-link">
            <div class="cp-copy-label">Payment Link</div>
            <div class="cp-copy-row">
                <div class="cp-copy-val">—</div>
                <button class="cp-copy-btn" data-copy="">Copy</button>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <?php if ( $cp_show_fee ) : ?>
    <div class="cp-checkout-footer">
        <div class="cp-rec-fee">
            <span style="color:#aaa;">Recommended fee:</span>
            <span class="cp-fee-text" id="cp-fee-text"></span>
        </div>
    </div>
    <?php endif; ?>

</div><!-- /cp-checkout-card -->

<?php wp_footer(); ?>
</body>
</html>
